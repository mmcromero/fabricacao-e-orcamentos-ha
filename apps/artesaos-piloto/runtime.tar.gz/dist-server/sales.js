import { Consigned } from './consigned.js';
import { randomUUID, createHash } from 'node:crypto';
import { PDFDocument } from 'pdf-lib';
import fontkit from '@pdf-lib/fontkit';
import { readFileSync } from 'node:fs';
import { ProductStock, StockError, stockText, stockInt } from './product-stock.js';
import { Finance, today, financeDate } from './finance.js';
import { reservedStock } from './stock-reservations.js';
import { addAttention } from './attention.js';
import { OperationConflict } from './foundation/operations.js';
import { divideRounded, safeInteger } from './foundation/decimal.js';
const amount = (n) => stockInt(n, 0, 10000000000);
function discount(total, input) { if (input === null)
    return 0; if (!input || !['percent', 'fixed'].includes(input.kind))
    throw new StockError(400, 'Desconto inválido.'); const value = stockInt(input.value, 0, input.kind === 'percent' ? 10000 : 10000000000); return input.kind === 'percent' ? safeInteger(divideRounded(BigInt(total) * BigInt(value), 10000n)) : Math.min(total, value); }
export class Sales {
    db;
    actor;
    stock;
    finance;
    constructor(db, actor) {
        this.db = db;
        this.actor = actor;
        this.stock = new ProductStock(db, actor);
        this.finance = new Finance(db, actor);
    }
    context(sessionId) { if (sessionId) {
        const session = this.db.prepare('SELECT * FROM sales_sessions WHERE id=?').get(stockText(sessionId, 100));
        if (!session || session.financial_closed_at)
            throw new StockError(409, 'Sessão não está aberta para vendas.');
        return { locationId: session.stock_control ? String(session.location_id) : 'central', sessionId };
    } return { locationId: 'central', sessionId: null }; }
    offer(line) { if (line.kind === 'consigned') {
        const item = new Consigned(this.db, this.actor).item(stockText(line.ref, 100));
        if (!item.active)
            throw new StockError(409, 'Consignado inativo.');
        return { ref: String(item.id), kind: 'consigned', productId: null, itemId: String(item.id), name: String(item.name), imageUrl: String(item.image_url), prices: { wholesale: null, factory: null, retail: Number(item.sale_price) }, snapshot: item, repass: Number(item.repass) };
    } if (line.kind !== 'own')
        throw new StockError(400, 'Tipo de produto inválido.'); const productId = stockInt(Number(stockText(line.ref, 100)), 1), p = this.stock.product(productId).data; if (p.origin !== 'own')
        throw new StockError(400, 'Produto de cliente é privado e não pode entrar em Venda Rápida.'); const item = this.db.prepare("SELECT * FROM stock_items WHERE product_id=? AND kind='own'").get(productId); return { ref: String(productId), kind: 'own', productId, itemId: item ? String(item.id) : null, name: p.name, imageUrl: p.imageUrl ?? '', prices: item ? JSON.parse(String(item.prices)) : p.prices, snapshot: p }; }
    preview(cart) {
        if (!Array.isArray(cart.items) || cart.items.length < 1 || cart.items.length > 100 || !['manual', 'coupon', 'combine'].includes(cart.discountChoice))
            throw new StockError(400, 'Inclua de um a 100 itens e confira a regra dos descontos.');
        const context = this.context(cart.sessionId), client = cart.clientId === null ? null : this.db.prepare('SELECT data FROM clients WHERE id=? AND archived=0').get(stockInt(cart.clientId, 1));
        if (cart.clientId !== null && !client)
            throw new StockError(400, 'Cliente não encontrado.');
        const code = stockText(cart.couponCode, 40, false).toUpperCase();
        if (!code && cart.discountChoice !== 'manual')
            throw new StockError(400, 'Informe um cupom ou escolha desconto manual.');
        let coupon = null;
        if (code && cart.discountChoice !== 'manual') {
            coupon = this.db.prepare('SELECT * FROM sale_coupons WHERE code=?').get(code) ?? null;
            if (!coupon || !coupon.active || coupon.starts_on && coupon.starts_on > today() || coupon.ends_on && coupon.ends_on < today())
                throw new StockError(400, 'Cupom não está ativo nesta data. Escolha desconto manual ou outro cupom.');
            const uses = Number(this.db.prepare('SELECT COUNT(*) n FROM sale_coupon_uses WHERE coupon_id=?').get(coupon.id).n);
            if (coupon.max_uses !== null && uses >= Number(coupon.max_uses))
                throw new StockError(409, 'Cupom atingiu o limite de usos.');
            coupon = { ...coupon, uses };
        }
        if (cart.discountChoice === 'combine' && (!coupon || !coupon.allow_manual))
            throw new StockError(400, 'Este cupom não combina com desconto manual. Escolha explicitamente cupom ou desconto manual.');
        const useManual = cart.discountChoice !== 'coupon';
        let subtotal = 0, itemDiscount = 0;
        const lines = cart.items.map(line => { const offer = this.offer(line), quantity = stockInt(line.quantity, 1, 1000000); if (!['wholesale', 'factory', 'retail', 'custom'].includes(line.priceKey))
            throw new StockError(400, 'Faixa de preço inválida.'); const unitPrice = line.priceKey === 'custom' ? amount(line.customPriceCents) : offer.prices[line.priceKey]; if (unitPrice === null || unitPrice === undefined)
            throw new StockError(400, 'Preço da faixa não informado. Escolha outra faixa ou preço personalizado.'); amount(unitPrice); const gross = safeInteger(BigInt(quantity) * BigInt(unitPrice)); amount(gross); subtotal = safeInteger(BigInt(subtotal) + BigInt(gross)); amount(subtotal); const manual = useManual ? discount(gross, line.discount) : 0; itemDiscount += manual; return { ...offer, quantity, priceKey: line.priceKey, unitPrice, gross, itemDiscount: manual, total: gross - manual }; });
        const afterItems = subtotal - itemDiscount, saleDiscount = useManual ? discount(afterItems, cart.discount) : 0, afterManual = afterItems - saleDiscount, couponDiscount = coupon ? discount(afterManual, { kind: coupon.kind, value: Number(coupon.value) }) : 0, total = afterManual - couponDiscount;
        let allocatedTotal = 0;
        const finalLines = lines.map((line, i) => { const finalTotal = i === lines.length - 1 ? total - allocatedTotal : afterItems ? safeInteger(BigInt(total) * BigInt(line.total) / BigInt(afterItems)) : 0; allocatedTotal += finalTotal; return { ...line, finalTotal }; });
        const company = this.db.prepare('SELECT data FROM company_profile WHERE id=1').get();
        const pricing = { lines: finalLines, subtotal, itemDiscount, saleDiscount, couponDiscount, total, coupon, client: client ? JSON.parse(String(client.data)) : null, clientId: cart.clientId, context, discountChoice: cart.discountChoice, company: company ? JSON.parse(String(company.data)) : null };
        const previewToken = createHash('sha256').update(JSON.stringify({ ...pricing, lines: pricing.lines.map(({ itemId, ...line }) => line) })).digest('hex');
        // Saldo é aviso; nunca integra o token ou bloqueia confirmação por divergência.
        const usedStock = new Map();
        const warnings = lines.flatMap(l => { const balance = l.kind === 'consigned' ? new Consigned(this.db, this.actor).balance(l.ref, context.locationId) : l.itemId ? this.stock.balance(l.itemId, context.locationId) : 0, available = balance - (l.kind === 'own' && l.itemId && context.locationId === 'central' ? reservedStock(this.db, l.itemId) : 0); const prior = usedStock.get(l.ref) ?? 0; usedStock.set(l.ref, prior + l.quantity); return available - prior < l.quantity ? [{ name: l.name, available: available - prior, quantity: l.quantity }] : []; });
        return { ...pricing, previewToken, warnings, sequence: 'Desconto dos itens → desconto da venda → cupom; percentuais arredondados por etapa.' };
    }
    confirm(input) {
        return this.stock.operation(input.requestKey, 'sale-confirm', 'new', input, () => {
            const preview = this.preview(input);
            if (stockText(input.previewToken, 64) !== preview.previewToken)
                throw new StockError(409, 'Preços ou cupom mudaram. Revise o total antes de finalizar.');
            if (!Array.isArray(input.payments) || input.payments.length > 20)
                throw new StockError(400, 'Confira as formas de pagamento.');
            const noncash = input.payments.filter(p => p.methodId !== 'cash'), cash = input.payments.filter(p => p.methodId === 'cash');
            let allocated = noncash.reduce((n, p) => n + amount(p.amountCents), 0);
            if (allocated > preview.total)
                throw new StockError(400, 'Pagamento não monetário supera o total. Confira os valores.');
            const parts = [...noncash];
            let change = 0;
            for (const p of cash) {
                const tendered = amount(p.amountCents), used = Math.min(tendered, preview.total - allocated);
                allocated += used;
                change += tendered - used;
                if (used)
                    parts.push({ ...p, amountCents: used });
            }
            safeInteger(BigInt(change));
            const id = randomUUID(), number = Number(this.db.prepare('SELECT COALESCE(MAX(number),0)+1 n FROM sales').get().n), titleId = 'sale:' + id, now = new Date().toISOString();
            this.db.prepare('INSERT INTO finance_titles(id,direction,origin,origin_id,amount_cents,client_id,description,metadata,created_at) VALUES(?,?,?,?,?,?,?,?,?)').run(titleId, 'in', 'sale', id, preview.total, input.clientId, 'Venda ' + number, JSON.stringify({ saleId: id, productIds: preview.lines.filter(l => l.kind === 'own').map(l => l.productId), consignedIds: preview.lines.filter(l => l.kind === 'consigned').map(l => l.ref), sessionId: preview.context.sessionId }), now);
            const snapshot = { ...preview, payments: input.payments, allocatedParts: parts, change };
            this.db.prepare('INSERT INTO sales VALUES(?,?,?,?,?,?,?,?,?)').run(id, number, input.clientId, preview.context.sessionId, preview.total, JSON.stringify(snapshot), titleId, this.actor, now);
            const attentions = [];
            preview.lines.forEach((line, index) => {
                const locationId = preview.context.locationId;
                let itemId, before, available;
                if (line.kind === 'consigned') {
                    const result = new Consigned(this.db, this.actor).sale(line.ref, locationId, line.quantity, id, index, line.finalTotal, preview.context.sessionId);
                    itemId = line.ref;
                    before = result.before;
                    available = before;
                }
                else {
                    const item = this.stock.ensureOwn(line.productId), ownId = String(item.id);
                    itemId = ownId;
                    before = this.stock.balance(itemId, locationId);
                    available = before - (locationId === 'central' ? reservedStock(this.db, itemId) : 0);
                    this.stock.move(itemId, locationId, -line.quantity, 'sale', id + ':' + index, 'Entrega imediata em Venda Rápida');
                }
                if (available < line.quantity)
                    attentions.push(addAttention(this.db, this.actor, { key: 'sale:' + id + ':' + index, kind: 'stock-divergence', sourceKind: 'sale', sourceId: id, itemRef: itemId, locationId, quantity: line.quantity - Math.max(0, available), valueCents: line.finalTotal, details: { name: line.name, kind: line.kind, productId: line.productId, consignedId: line.kind === 'consigned' ? line.ref : null, line: index, before, available, delivered: line.quantity }, href: line.kind === 'consigned' ? '?view=estoque&tab=consigned&consignedId=' + encodeURIComponent(line.ref) : '?view=estoque&productId=' + line.productId + '&locationId=' + encodeURIComponent(locationId), priority: 'high' }));
            });
            if (preview.coupon)
                this.db.prepare('INSERT INTO sale_coupon_uses VALUES(?,?,?)').run(id, preview.coupon.id, preview.couponDiscount);
            this.finance.entry({ titleId, accountId: null, allocation: 0, cash: 0, kind: 'title-created', sourceId: titleId, snapshot: { saleId: id, total: preview.total } });
            if (parts.length)
                this.finance.pay(titleId, { requestKey: id + ':payment', expectedRevision: 1, allowExcess: false, parts });
            return { id, number, total: preview.total, change, attentions };
        });
    }
    get(saleId) { const sale = this.db.prepare('SELECT * FROM sales WHERE id=?').get(stockText(saleId, 100)); if (!sale)
        throw new StockError(404, 'Venda não encontrada.'); return { ...sale, id: String(sale.id), registered_at: String(sale.registered_at), number: Number(sale.number), snapshot: JSON.parse(String(sale.snapshot)), financial: this.finance.title(String(sale.title_id)), payments: this.db.prepare('SELECT * FROM finance_payments WHERE title_id=? ORDER BY created_at').all(sale.title_id) }; }
    couponSave(input) { return this.stock.operation(input.requestKey, 'coupon-save', input.id ?? 'new', input, () => { const code = stockText(input.code, 40).toUpperCase(); if (!/^[A-Z0-9_-]{3,40}$/.test(code) || !['percent', 'fixed'].includes(input.kind) || typeof input.active !== 'boolean' || typeof input.allowManual !== 'boolean')
        throw new StockError(400, 'Confira código, tipo e situação do cupom.'); const value = stockInt(input.value, 0, input.kind === 'percent' ? 10000 : 10000000000), starts = input.startsOn ? financeDate(input.startsOn) : null, ends = input.endsOn ? financeDate(input.endsOn) : null; if (starts && ends && starts > ends)
        throw new StockError(400, 'Vigência final deve ser posterior à inicial.'); const max = input.maxUses === null ? null : stockInt(input.maxUses, 1), id = input.id ?? randomUUID(); if (input.id) {
        if (!this.db.prepare('UPDATE sale_coupons SET code=?,kind=?,value=?,starts_on=?,ends_on=?,max_uses=?,active=?,allow_manual=?,revision=revision+1 WHERE id=? AND revision=?').run(code, input.kind, value, starts, ends, max, input.active ? 1 : 0, input.allowManual ? 1 : 0, id, stockInt(input.expectedRevision, 1)).changes)
            throw new StockError(409, 'Cupom alterado.');
    }
    else
        this.db.prepare('INSERT INTO sale_coupons(id,code,kind,value,starts_on,ends_on,max_uses,active,allow_manual) VALUES(?,?,?,?,?,?,?,?,?)').run(id, code, input.kind, value, starts, ends, max, input.active ? 1 : 0, input.allowManual ? 1 : 0); return { id }; }); }
    receiptText(saleId) { const sale = this.get(saleId), s = sale.snapshot, f = sale.financial, money = (n) => (n / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }); return ['COMPROVANTE NÃO FISCAL', s.company?.name ?? 'Artesão Digital', 'Venda ' + sale.number + ' · ' + sale.registered_at, ...(s.client ? [s.client.name || s.client.contact] : []), ...s.lines.map((l) => `${l.name} · ${l.quantity} un x ${money(l.unitPrice)} · ${money(l.total)}`), `Subtotal: ${money(s.subtotal)}`, `Descontos dos itens: ${money(s.itemDiscount)}`, `Desconto da venda: ${money(s.saleDiscount)}`, `Cupom: ${money(s.couponDiscount)}`, `Total: ${money(s.total)}`, `Liquidado: ${money(f.allocated)}`, `Saldo a receber: ${money(Math.max(0, f.remaining))}`, `Pagamento futuro/agendado: ${money(f.scheduled)}`, `Troco na venda: ${money(s.change)}`, ...sale.payments.map(p => `${p.method_id} · ${money(Number(p.amount_cents))} · ${p.state === 'settled' ? 'Liquidado' : p.state === 'scheduled' ? 'Agendado, não recebido' : 'Cancelado'}`), 'Documento comercial; não é nota fiscal.'].join('\n'); }
}
export function registerSales(app, db, actor) {
    const sales = new Sales(db, actor);
    const route = (fn) => async (req, reply) => { try {
        return await fn(req);
    }
    catch (e) {
        return reply.code(e instanceof StockError ? e.status : e instanceof OperationConflict ? 409 : 400).send({ message: e instanceof StockError || e instanceof OperationConflict ? e.message : 'Não foi possível registrar a venda. Confira os dados.' });
    } };
    app.get('/api/sales', route(req => { const before = req.query.before ? stockInt(Number(req.query.before), 1) : null; return db.prepare('SELECT id,number,total_cents,registered_at FROM sales' + (before ? ' WHERE number<?' : '') + ' ORDER BY number DESC LIMIT 200').all(...(before ? [before] : [])); }));
    app.get('/api/sales/:id', route(req => sales.get(req.params.id)));
    app.post('/api/sales/preview', { bodyLimit: 131072 }, route(req => sales.preview(req.body)));
    app.post('/api/sales', { bodyLimit: 262144 }, route(req => sales.confirm(req.body)));
    app.get('/api/sale-coupons', () => db.prepare('SELECT c.*,(SELECT COUNT(*) FROM sale_coupon_uses u WHERE u.coupon_id=c.id) uses FROM sale_coupons c ORDER BY rowid DESC').all());
    app.get('/api/sale-coupons/:id/history', route(req => db.prepare('SELECT s.id,s.number,s.registered_at,u.discount_cents FROM sale_coupon_uses u JOIN sales s ON s.id=u.sale_id WHERE u.coupon_id=? ORDER BY s.number DESC').all(req.params.id)));
    app.post('/api/sale-coupons', { bodyLimit: 8192 }, route(req => sales.couponSave(req.body)));
    app.get('/api/sales/:id/receipt', route(req => ({ text: sales.receiptText(req.params.id) })));
    app.get('/api/sales/:id/receipt.pdf', async (req, reply) => { try {
        const text = sales.receiptText(req.params.id), doc = await PDFDocument.create();
        doc.registerFontkit(fontkit);
        const font = await doc.embedFont(readFileSync(new URL('../assets/fonts/NotoSans-Regular.ttf', import.meta.url)), { subset: true }), supported = new Set(font.getCharacterSet());
        let page = doc.addPage(), y = 800, pages = 1;
        const draw = (value) => { if (y < 45) {
            if (++pages > 40)
                throw new StockError(400, 'Comprovante excede o limite de páginas.');
            page = doc.addPage();
            y = 800;
        } page.drawText(value, { x: 40, y, size: 10, font }); y -= 16; };
        for (const original of text.split('\n')) {
            const clean = Array.from(original.replace(/[\x00-\x1f\x7f]/g, ' ')).map(c => supported.has(c.codePointAt(0)) ? c : '?').join('');
            let line = '';
            for (const char of clean) {
                if (font.widthOfTextAtSize(line + char, 10) > 515) {
                    draw(line);
                    line = '';
                }
                line += char;
            }
            draw(line);
        }
        return reply.type('application/pdf').header('Content-Disposition', 'attachment; filename="comprovante-nao-fiscal.pdf"').send(Buffer.from(await doc.save()));
    }
    catch (e) {
        return reply.code(e instanceof StockError ? e.status : 400).send({ message: e instanceof StockError ? e.message : 'Não foi possível gerar o comprovante.' });
    } });
}
