import { randomUUID } from 'node:crypto';
export function addAttention(db, actor, input) {
    const previous = db.prepare('SELECT id FROM attention_events WHERE occurrence_key=?').get(input.key);
    if (previous)
        return String(previous.id);
    const id = randomUUID(), now = new Date().toISOString();
    db.prepare('INSERT INTO attention_events(id,occurrence_key,kind,source_kind,source_id,item_ref,location_id,quantity,value_cents,details,action_href,priority,responsible,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)').run(id, input.key, input.kind, input.sourceKind, input.sourceId, input.itemRef ?? null, input.locationId ?? null, input.quantity ?? null, input.valueCents ?? null, JSON.stringify(input.details), input.href, input.priority ?? 'normal', actor, now);
    db.prepare('INSERT INTO attention_history(attention_id,action,reason,actor,registered_at) VALUES(?,?,?,?,?)').run(id, 'created', 'Ocorrência registrada na operação de origem', actor, now);
    return id;
}
export function captureClientExcess(db, actor, orderId) {
    if (!db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='attention_events'").get())
        return;
    const order = db.prepare('SELECT revision FROM orders WHERE id=?').get(orderId);
    if (!order)
        return;
    for (const item of db.prepare("SELECT s.*,p.data FROM stock_items s JOIN products p ON p.id=s.product_id WHERE s.kind='client' AND s.order_id=?").all(orderId)) {
        const balance = Number(db.prepare("SELECT COALESCE(SUM(delta),0) n FROM product_stock_movements WHERE item_id=? AND location_id='central'").get(item.id).n), reserved = Number(db.prepare('SELECT COALESCE(SUM(quantity),0) n FROM stock_reservations WHERE item_id=?').get(item.id).n), excess = balance - reserved;
        if (excess <= 0)
            continue;
        const open = db.prepare("SELECT id,quantity FROM attention_events WHERE kind='client-excess' AND item_ref=? AND state='open'").get(item.id);
        if (open) {
            if (Number(open.quantity) !== excess) {
                db.prepare('UPDATE attention_events SET quantity=? WHERE id=?').run(excess, open.id);
                db.prepare('INSERT INTO attention_history(attention_id,action,reason,actor,registered_at) VALUES(?,?,?,?,?)').run(open.id, 'quantity-revised', JSON.stringify({ before: open.quantity, after: excess, orderRevision: order.revision }), actor, new Date().toISOString());
            }
            continue;
        }
        addAttention(db, actor, { key: 'client-excess:' + item.id + ':' + order.revision, kind: 'client-excess', sourceKind: 'order', sourceId: orderId, itemRef: String(item.id), locationId: 'central', quantity: excess, details: { name: JSON.parse(String(item.data)).name, productId: item.product_id }, href: '?view=estoque&tab=client&orderId=' + encodeURIComponent(orderId) });
    }
}
/** Fechamento por fluxo de origem, dentro da transação da operação efetiva. */
export function closeAttention(db, actor, attentionId, reason) { const row = db.prepare('SELECT state FROM attention_events WHERE id=?').get(attentionId); if (!row || row.state === 'resolved')
    return; const now = new Date().toISOString(); db.prepare("UPDATE attention_events SET state='resolved',resolved_at=? WHERE id=?").run(now, attentionId); db.prepare('INSERT INTO attention_history(attention_id,action,reason,actor,registered_at) VALUES(?,?,?,?,?)').run(attentionId, 'resolved', reason, actor, now); }
function attentionReady(db) { return !!db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='attention_events'").get(); }
export function financialAttention(db, actor, titleId) {
    if (!attentionReady(db))
        return;
    const title = db.prepare('SELECT * FROM finance_titles WHERE id=?').get(titleId);
    if (!title)
        return;
    const allocated = Number(db.prepare('SELECT COALESCE(SUM(allocation_cents),0) n FROM finance_entries WHERE title_id=?').get(titleId).n), remaining = Number(title.amount_cents) - allocated, day = new Date().toISOString().slice(0, 10), overdue = !!title.due_on && String(title.due_on) < day && remaining > 0, excess = title.direction === 'in' && remaining < 0;
    for (const [kind, needed, value] of [['financial-overdue', overdue, Math.max(0, remaining)], ['financial-excess', excess, Math.max(0, -remaining)]]) {
        const rows = db.prepare("SELECT * FROM attention_events WHERE kind=? AND source_kind='financial-title' AND source_id=? AND state='open'").all(kind, titleId);
        if (!needed) {
            for (const row of rows)
                closeAttention(db, actor, String(row.id), 'Situação atendida por operação financeira registrada ou revisão do vencimento.');
            continue;
        }
        const open = rows[0];
        if (open) {
            if (Number(open.value_cents) !== value) {
                db.prepare('UPDATE attention_events SET value_cents=? WHERE id=?').run(value, open.id);
                db.prepare('INSERT INTO attention_history(attention_id,action,reason,actor,registered_at) VALUES(?,?,?,?,?)').run(open.id, 'value-revised', JSON.stringify({ before: open.value_cents, after: value }), actor, new Date().toISOString());
            }
            continue;
        }
        const last = db.prepare('SELECT id FROM finance_entries WHERE title_id=? ORDER BY rowid DESC LIMIT 1').get(titleId);
        addAttention(db, actor, { key: kind + ':' + titleId + ':' + String(last?.id ?? title.revision), kind, sourceKind: 'financial-title', sourceId: titleId, valueCents: value, details: { description: title.description, dueOn: title.due_on, direction: title.direction, origin: title.origin }, href: '?view=financeiro&title=' + encodeURIComponent(titleId), priority: 'high' });
    }
}
export function materialDeficitAttention(db, actor, materialId, sourceId) { if (!attentionReady(db))
    return; const current = Number(db.prepare('SELECT COALESCE(SUM(delta_micro),0) n FROM material_movements WHERE material_id=? AND lot_id IS NULL').get(materialId).n); if (current >= 0)
    return; const cutoff = Number(db.prepare("SELECT COALESCE(MAX(id),0) n FROM material_movements WHERE material_id=? AND lot_id IS NULL AND kind='correction' AND after_micro=0").get(materialId).n); const event = db.prepare("SELECT COALESCE(SUM(-delta_micro),0) n FROM material_movements WHERE material_id=? AND source_id=? AND kind='deficit' AND id>?").get(materialId, sourceId, cutoff); if (Number(event.n) <= 0)
    return; const material = db.prepare('SELECT data FROM materials WHERE id=?').get(materialId), profile = db.prepare('SELECT data FROM material_profiles WHERE material_id=?').get(materialId), name = material ? JSON.parse(String(material.data)).name : 'Material', unit = profile ? JSON.parse(String(profile.data)).unit : material ? { kg: 'g', g: 'g', l: 'ml', ml: 'ml', mm: 'mm', cm: 'mm', m: 'mm', un: 'un', custom: 'custom' }[JSON.parse(String(material.data)).purchaseUnit] : 'un'; const n = BigInt(Number(event.n)), quantityText = String(n / 1000000n) + '.' + String(n % 1000000n).padStart(6, '0'); addAttention(db, actor, { key: 'material-deficit:' + materialId + ':' + sourceId, kind: 'material-deficit', sourceKind: 'material-consumption', sourceId, itemRef: String(materialId), details: { name, materialId, quantityText, unit }, href: '?view=estoque&section=materiais&materialId=' + materialId, priority: 'high' }); }
export function closeMaterialDeficit(db, actor, materialId, reason) { if (!attentionReady(db))
    return; const deficit = Number(db.prepare('SELECT COALESCE(SUM(delta_micro),0) n FROM material_movements WHERE material_id=? AND lot_id IS NULL').get(materialId).n); if (deficit < 0)
    return; for (const row of db.prepare("SELECT id FROM attention_events WHERE kind='material-deficit' AND item_ref=? AND state='open'").all(String(materialId)))
    closeAttention(db, actor, String(row.id), reason); }
export function matchesStockAttention(db, attentionId, itemId, locationId, kind) {
    if (!attentionReady(db))
        return false;
    const row = db.prepare("SELECT * FROM attention_events WHERE id=? AND kind='stock-divergence' AND state='open' AND item_ref=? AND location_id=?").get(attentionId, itemId, locationId);
    if (!row)
        return false;
    const detail = JSON.parse(String(row.details));
    return (detail.kind === 'consigned' ? 'consigned' : 'own') === kind;
}
