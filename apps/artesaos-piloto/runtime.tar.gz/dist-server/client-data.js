const text = (maxLength) => ({ type: 'string', maxLength });
export const clientSchema = { type: 'object', additionalProperties: false, required: ['name', 'contact', 'phone', 'email', 'taxDocument', 'postal'], anyOf: [{ properties: { name: { type: 'string', pattern: '\\S' } } }, { properties: { contact: { type: 'string', pattern: '\\S' } } }], properties: {
        commercialType: { enum: ['wholesale', 'retail', 'undefined'] }, registrationOrigin: { enum: ['quote', 'sale', 'direct', 'undefined'] }, captureSessionId: { anyOf: [{ type: 'string', maxLength: 100 }, { type: 'null' }] }, name: text(200), contact: text(200), phone: text(50), email: { anyOf: [{ type: 'string', maxLength: 254, format: 'email' }, { const: '' }] }, taxDocument: text(40), postal: text(20),
        street: text(200), number: text(30), complement: text(200), district: text(100), city: text(100), state: text(2)
    } };
export function normalizeClient(data) { return { ...data, name: data.name.trim(), contact: data.contact.trim(), street: data.street ?? '', number: data.number ?? '', complement: data.complement ?? '', district: data.district ?? '', city: data.city ?? '', state: data.state ?? '' }; }
