export const supportKinds = { question: 'Dúvida de uso', bug: 'Relatar erro' };
export const supportStatuses = { open: 'Em aberto', analysis: 'Em análise', answered: 'Respondido', waiting_customer: 'Aguardando resposta do cliente', closed: 'Finalizado' };
