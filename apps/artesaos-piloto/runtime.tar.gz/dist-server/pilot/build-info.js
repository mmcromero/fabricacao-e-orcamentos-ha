// Generated from the pilot manifest, core package and pinned base reference.
export const buildInfo = { "pilotVersion": "0.2.0-dev.15", "coreVersion": "0.1.23", "coreCommit": "f56f0e5707ad81f74f42c351171d4132f793cf9a", "releaseVersion": "0.2.0-dev.15", "schemaVersions": { "tenant": 11, "control": 4, "interest": 2, "support": 2, "legal": 3 } };
