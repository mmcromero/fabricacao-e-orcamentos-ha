import { StockError, stockText, stockInt } from './product-stock.js';
import { executeOperation, OperationConflict } from './foundation/operations.js';
import { transaction } from './foundation/transaction.js';
import { financialAttention, materialDeficitAttention, captureClientExcess, closeAttention } from './attention.js';
export class AttentionCenter {
    db;
    actor;
    constructor(db, actor) {
        this.db = db;
        this.actor = actor;
        db.function('attention_search', { deterministic: true }, value => String(value ?? '').normalize('NFD').replace(/\p{Diacritic}/gu, '').toLocaleLowerCase('pt-BR'));
    }
    scan(full = true) {
        return transaction(this.db, () => {
            const day = new Date().toISOString().slice(0, 10);
            const candidates = this.db.prepare("SELECT t.id FROM finance_titles t LEFT JOIN (SELECT title_id,SUM(allocation_cents) allocated FROM finance_entries GROUP BY title_id) e ON e.title_id=t.id WHERE (t.due_on<? AND t.amount_cents-COALESCE(e.allocated,0)>0) OR (t.direction='in' AND t.amount_cents-COALESCE(e.allocated,0)<0) OR EXISTS(SELECT 1 FROM attention_events a WHERE a.kind IN ('financial-overdue','financial-excess') AND a.source_kind='financial-title' AND a.source_id=t.id AND a.state='open')").all(day);
            for (const title of candidates)
                financialAttention(this.db, this.actor, String(title.id));
            if (!full)
                return;
            for (const material of this.db.prepare('SELECT material_id FROM material_movements WHERE lot_id IS NULL GROUP BY material_id HAVING SUM(delta_micro)<0').all()) {
                const materialId = Number(material.material_id), cutoff = Number(this.db.prepare("SELECT COALESCE(MAX(id),0) n FROM material_movements WHERE material_id=? AND lot_id IS NULL AND kind='correction' AND after_micro=0").get(materialId).n);
                for (const row of this.db.prepare("SELECT DISTINCT m.source_id FROM material_movements m WHERE m.material_id=? AND m.kind='deficit' AND m.id>? AND NOT EXISTS(SELECT 1 FROM attention_events a WHERE a.occurrence_key='material-deficit:'||m.material_id||':'||m.source_id)").all(materialId, cutoff))
                    materialDeficitAttention(this.db, this.actor, materialId, String(row.source_id));
            }
            for (const order of this.db.prepare("SELECT DISTINCT order_id FROM stock_items WHERE kind='client'").all())
                captureClientExcess(this.db, this.actor, String(order.order_id));
        });
    }
    get(attentionId) { const row = this.db.prepare('SELECT * FROM attention_events WHERE id=?').get(stockText(attentionId, 100)); if (!row)
        throw new StockError(404, 'Pendência não encontrada.'); return { ...row, id: String(row.id), kind: String(row.kind), state: String(row.state), source_id: String(row.source_id), item_ref: row.item_ref === null ? null : String(row.item_ref), location_id: row.location_id === null ? null : String(row.location_id), details: JSON.parse(String(row.details)), history: this.db.prepare('SELECT * FROM attention_history WHERE attention_id=? ORDER BY id').all(attentionId) }; }
    list(filters = {}) { const state = filters.state ?? 'open'; if (!['open', 'resolved', 'all'].includes(String(state)))
        throw new StockError(400, 'Situação inválida.'); const kind = filters.kind ? stockText(filters.kind, 50) : '', search = stockText(filters.search ?? '', 100, false).normalize('NFD').replace(/\p{Diacritic}/gu, '').toLocaleLowerCase('pt-BR'); const args = []; let where = '1=1'; if (state !== 'all') {
        where += ' AND state=?';
        args.push(String(state));
    } if (kind) {
        where += ' AND kind=?';
        args.push(kind);
    } if (filters.priority) {
        if (!['normal', 'high'].includes(String(filters.priority)))
            throw new StockError(400, 'Prioridade inválida.');
        where += ' AND priority=?';
        args.push(String(filters.priority));
    } if (search) {
        where += " AND (attention_search(details) LIKE ? ESCAPE '!' OR source_id LIKE ? ESCAPE '!')";
        const pattern = '%' + search.replace(/[!%_]/g, '!$&') + '%';
        args.push(pattern, pattern);
    } const total = Number(this.db.prepare('SELECT COUNT(*) n FROM attention_events WHERE ' + where).get(...args).n), pages = Math.max(1, Math.ceil(total / 30)), page = Math.min(filters.page === undefined ? 1 : stockInt(Number(filters.page), 1, 1000000), pages), rows = this.db.prepare("SELECT id FROM attention_events WHERE " + where + " ORDER BY CASE priority WHEN 'high' THEN 0 ELSE 1 END,created_at DESC,rowid DESC LIMIT 30 OFFSET ?").all(...args, (page - 1) * 30).map(r => this.get(String(r.id))), groups = new Map(); for (const row of rows) {
        const key = [row.kind, row.item_ref ?? row.source_id, row.location_id ?? '', row.state].join('|');
        groups.set(key, [...(groups.get(key) ?? []), row]);
    } return { items: rows, groups: [...groups].map(([key, items]) => ({ key, items })), total, page, pages, openCount: Number(this.db.prepare("SELECT COUNT(*) n FROM attention_events WHERE state='open'").get().n) }; }
    canVerify(row) {
        if (row.kind === 'stock-divergence') {
            const table = row.details.kind === 'consigned' ? 'consigned_movements' : 'product_stock_movements';
            const balance = Number(this.db.prepare('SELECT COALESCE(SUM(delta),0) n FROM ' + table + ' WHERE ' + (table === 'consigned_movements' ? 'item_id' : 'item_id') + '=? AND location_id=?').get(row.item_ref, row.location_id).n);
            if (balance < 0)
                throw new StockError(409, 'Saldo do local continua negativo. Corrija o inventário antes de confirmar a conferência.');
        }
        else if (row.kind === 'material-deficit') {
            const balance = Number(this.db.prepare('SELECT COALESCE(SUM(delta_micro),0) n FROM material_movements WHERE material_id=? AND lot_id IS NULL').get(row.details.materialId).n);
            if (balance < 0)
                throw new StockError(409, 'Déficit não identificado ainda precisa de conciliação justificada.');
        }
        else if (row.kind === 'client-excess') {
            const balance = Number(this.db.prepare("SELECT COALESCE(SUM(delta),0) n FROM product_stock_movements WHERE item_id=? AND location_id='central'").get(row.item_ref).n), reserved = Number(this.db.prepare('SELECT COALESCE(SUM(quantity),0) n FROM stock_reservations WHERE item_id=?').get(row.item_ref).n);
            if (balance > reserved)
                throw new StockError(409, 'Há peças privadas aguardando destinação. Use o fluxo de destinação; manter pendente não resolve a ocorrência.');
        }
        else if (row.kind === 'session-count') {
            if (!this.db.prepare('SELECT physical_closed_at FROM sales_sessions WHERE id=?').get(row.source_id)?.physical_closed_at)
                throw new StockError(409, 'Use a conferência física da sessão antes de resolver.');
        }
        else if (row.kind === 'financial-overdue' || row.kind === 'financial-excess') {
            const title = this.db.prepare('SELECT amount_cents,due_on FROM finance_titles WHERE id=?').get(row.source_id);
            if (!title)
                throw new StockError(404, 'Título de origem não encontrado.');
            const allocated = Number(this.db.prepare('SELECT COALESCE(SUM(allocation_cents),0) n FROM finance_entries WHERE title_id=?').get(row.source_id).n), remaining = Number(title.amount_cents) - allocated, late = title.due_on && String(title.due_on) < new Date().toISOString().slice(0, 10);
            if (row.kind === 'financial-excess' ? remaining < 0 : remaining > 0 && late)
                throw new StockError(409, 'Trate o lançamento financeiro de origem antes de resolver.');
        }
        else
            throw new StockError(400, 'Tipo de pendência exige fluxo específico.');
    }
    treat(attentionId, input) { return executeOperation(this.db, { scope: 'attention', key: stockText(input.requestKey, 100), actor: this.actor, action: stockText(input.action, 20), sourceId: stockText(attentionId, 100), request: input }, () => { const row = this.get(attentionId); if (typeof input.reason !== 'string' || !input.reason.trim() || input.reason.length > 1000 || /[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/.test(input.reason))
        throw new StockError(400, 'Informe uma justificativa válida.'); const reason = input.reason.trim(); if (!['note', 'verify'].includes(input.action))
        throw new StockError(400, 'Ação inválida.'); if (row.state === 'resolved')
        throw new StockError(409, 'Pendência já resolvida. Consulte o histórico.'); if (input.action === 'verify') {
        this.canVerify(row);
        closeAttention(this.db, this.actor, attentionId, 'Conferência justificada: ' + reason);
    }
    else
        this.db.prepare('INSERT INTO attention_history(attention_id,action,reason,actor,registered_at) VALUES(?,?,?,?,?)').run(attentionId, 'note', reason, this.actor, new Date().toISOString()); return { id: attentionId, state: input.action === 'verify' ? 'resolved' : 'open' }; }).result; }
}
export function registerAttentionCenter(app, db, actor) {
    const center = new AttentionCenter(db, actor);
    let timer;
    app.addHook('onReady', async () => { center.scan(); timer = setInterval(() => { try {
        center.scan(false);
    }
    catch {
        app.log.warn('Atualização das pendências será repetida; histórico preservado.');
    } }, 60000); timer.unref(); });
    app.addHook('onClose', async () => { if (timer)
        clearInterval(timer); });
    const route = (fn) => async (req, reply) => { try {
        return fn(req);
    }
    catch (e) {
        return reply.code(e instanceof StockError ? e.status : e instanceof OperationConflict ? 409 : 400).send({ message: e instanceof StockError || e instanceof OperationConflict ? e.message : 'Não foi possível tratar a pendência. Confira os dados.' });
    } };
    app.get('/api/attention', route(req => center.list(req.query)));
    app.get('/api/attention/count', () => ({ open: Number(db.prepare("SELECT COUNT(*) n FROM attention_events WHERE state='open'").get().n) }));
    app.get('/api/attention/:id', route(req => center.get(req.params.id)));
    app.post('/api/attention/:id/treat', { bodyLimit: 8192 }, route(req => center.treat(req.params.id, req.body)));
}
