import { randomUUID } from 'node:crypto';
import { ProductStock, StockError, stockInt, stockText } from './product-stock.js';
import { reservedStock, refreshReservations } from './stock-reservations.js';
import { Finance, financeDate } from './finance.js';
import { Consigned } from './consigned.js';
import { addAttention, captureClientExcess } from './attention.js';
import { OperationConflict } from './foundation/operations.js';
import { safeInteger } from './foundation/decimal.js';
export class Distribution {
    db;
    actor;
    stock;
    consigned;
    finance;
    constructor(db, actor) {
        this.db = db;
        this.actor = actor;
        this.stock = new ProductStock(db, actor);
        this.consigned = new Consigned(db, actor);
        this.finance = new Finance(db, actor);
    }
    placeSave(input) { return this.stock.operation(input.requestKey, 'place-save', input.id ?? 'new', input, () => { const name = stockText(input.name, 200), address = stockText(input.address, 400, false), notes = stockText(input.notes, 1000, false); if (typeof input.active !== 'boolean')
        throw new StockError(400, 'Situação inválida.'); const id = input.id ?? randomUUID(); if (input.id) {
        if (!this.db.prepare('UPDATE sales_places SET name=?,address=?,notes=?,active=?,revision=revision+1 WHERE id=? AND revision=?').run(name, address, notes, input.active ? 1 : 0, id, stockInt(input.expectedRevision, 1)).changes)
            throw new StockError(409, 'Local alterado.');
    }
    else
        this.db.prepare('INSERT INTO sales_places(id,name,address,notes,active) VALUES(?,?,?,?,?)').run(id, name, address, notes, input.active ? 1 : 0); return { id }; }); }
    session(sessionId) { const row = this.db.prepare('SELECT s.*,p.name FROM sales_sessions s JOIN sales_places p ON p.id=s.place_id WHERE s.id=?').get(stockText(sessionId, 100)); if (!row)
        throw new StockError(404, 'Sessão não encontrada.'); return row; }
    sessions() { return this.db.prepare('SELECT id FROM sales_sessions ORDER BY created_at DESC,rowid DESC').all().map(r => this.session(String(r.id))); }
    openSession(input) { return this.stock.operation(input.requestKey, 'session-open', 'new', input, () => { const place = this.db.prepare('SELECT * FROM sales_places WHERE id=? AND active=1').get(stockText(input.placeId, 100)); if (!place || !['wholesale', 'factory', 'retail'].includes(input.tier) || typeof input.stockControl !== 'boolean')
        throw new StockError(400, 'Confira local, tabela e controle físico.'); const dateOn = financeDate(input.dateOn), id = randomUUID(), locationId = input.stockControl ? 'session:' + id : null; if (locationId)
        this.db.prepare('INSERT INTO stock_locations VALUES(?,?,?,1)').run(locationId, place.name + ' · ' + dateOn, 'session'); this.db.prepare('INSERT INTO sales_sessions(id,place_id,date_on,tier,stock_control,location_id,created_at) VALUES(?,?,?,?,?,?,?)').run(id, input.placeId, dateOn, input.tier, input.stockControl ? 1 : 0, locationId, new Date().toISOString()); return { id }; }); }
    supply(sessionId, input) { return this.stock.operation(input.requestKey, 'session-supply', sessionId, input, () => { const s = this.session(sessionId); if (s.financial_closed_at || !s.stock_control)
        throw new StockError(409, 'Reforço somente em sessão aberta com estoque separado.'); const quantity = stockInt(input.quantity, 1, 1000000); if (input.kind === 'own') {
        const item = this.stock.ensureOwn(stockInt(Number(input.ref), 1)), itemId = String(item.id), available = this.stock.balance(itemId, 'central') - reservedStock(this.db, itemId);
        if (available < quantity)
            throw new StockError(409, 'Disponibilidade central insuficiente; confira o estoque.');
        this.stock.move(itemId, 'central', -quantity, 'session-transfer', sessionId, 'Estoque levado à sessão');
        this.stock.move(itemId, String(s.location_id), quantity, 'session-transfer', sessionId, 'Estoque levado à sessão');
    }
    else if (input.kind === 'consigned')
        this.consigned.transfer(input.ref, 'central', String(s.location_id), quantity, sessionId, 'Consignado levado à sessão');
    else
        throw new StockError(400, 'Tipo de produto inválido.'); return { supplied: quantity }; }); }
    sessionSummary(sessionId) { const s = this.session(sessionId), location = s.location_id ? String(s.location_id) : 'central'; return { session: s, finance: this.finance.summary({ sessionId }), own: s.stock_control ? this.stock.list().filter(r => r.kind === 'own' && r.locations.some(l => l.id === location && l.quantity !== 0)).map(r => ({ id: r.id, product: r.product, quantity: this.stock.balance(String(r.id), location) })) : [], consigned: s.stock_control ? this.consigned.list().filter(r => this.consigned.balance(String(r.id), location) !== 0).map(r => ({ ...r, quantity: this.consigned.balance(String(r.id), location) })) : [] }; }
    closeSession(sessionId, input) {
        return this.stock.operation(input.requestKey, 'session-close', sessionId, input, () => {
            const s = this.session(sessionId), reason = stockText(input.reason, 1000);
            if (s.revision !== stockInt(input.expectedRevision, 1) || s.physical_closed_at)
                throw new StockError(409, 'Sessão já conferida ou alterada.');
            if (!['return', 'pending'].includes(input.physical))
                throw new StockError(400, 'Escolha devolver sobras ou deixar conferência pendente.');
            let pending = !!s.stock_control && input.physical === 'pending';
            if (s.stock_control && input.physical === 'return') {
                const locationId = String(s.location_id);
                for (const item of this.stock.list().filter(i => i.kind === 'own')) {
                    const q = this.stock.balance(String(item.id), locationId);
                    if (q < 0)
                        pending = true;
                    else if (q > 0) {
                        this.stock.move(String(item.id), locationId, -q, 'session-return', sessionId, reason);
                        this.stock.move(String(item.id), 'central', q, 'session-return', sessionId, reason);
                    }
                }
                for (const item of this.consigned.list()) {
                    const q = this.consigned.balance(String(item.id), locationId);
                    if (q < 0)
                        pending = true;
                    else if (q > 0)
                        this.consigned.transfer(String(item.id), locationId, 'central', q, sessionId, reason);
                }
            }
            const now = new Date().toISOString();
            this.db.prepare('UPDATE sales_sessions SET financial_closed_at=COALESCE(financial_closed_at,?),physical_closed_at=?,revision=revision+1 WHERE id=?').run(now, pending ? null : now, sessionId);
            if (pending)
                addAttention(this.db, this.actor, { key: 'session-count:' + sessionId, kind: 'session-count', sourceKind: 'session', sourceId: sessionId, locationId: s.location_id ? String(s.location_id) : undefined, details: { name: s.name, reason }, href: '?view=vendas&session=' + encodeURIComponent(sessionId) });
            else if (s.location_id) {
                this.db.prepare('UPDATE stock_locations SET active=0 WHERE id=?').run(s.location_id);
                this.resolveSource('session-count', sessionId, reason);
            }
            return { financialClosed: true, physicalPending: pending };
        });
    }
    sessionExpense(sessionId, input) { return this.stock.operation(input.requestKey, 'session-expense', sessionId, input, () => { const s = this.session(sessionId), amount = stockInt(input.amountCents, 0, 10000000000), description = stockText(input.description, 200), due = input.dueOn ? financeDate(input.dueOn) : null, id = randomUUID(); this.db.prepare('INSERT INTO finance_titles(id,direction,origin,origin_id,amount_cents,due_on,description,metadata,created_at) VALUES(?,?,?,?,?,?,?,?,?)').run(id, 'out', 'session_expense', id, amount, due, description, JSON.stringify({ sessionId, name: s.name }), new Date().toISOString()); this.finance.entry({ titleId: id, accountId: null, allocation: 0, cash: 0, kind: 'title-created', sourceId: id, snapshot: input }); return { id }; }); }
    partner(partnerId) { const row = this.db.prepare('SELECT * FROM stock_partners WHERE id=?').get(stockText(partnerId, 100)); if (!row)
        throw new StockError(404, 'Ponto parceiro não encontrado.'); return row; }
    partnerSave(input) { return this.stock.operation(input.requestKey, 'partner-save', input.id ?? 'new', input, () => { const name = stockText(input.name, 200), contact = stockText(input.contact, 200, false), phone = stockText(input.phone, 50, false), email = stockText(input.email, 254, false), tax = stockText(input.taxDocument, 40, false), address = stockText(input.address, 400, false), notes = stockText(input.notes, 1000, false); if (!phone && !email || phone && (!/^[\d+(). -]+$/.test(phone) || phone.replace(/\D/g, '').length < 7) || email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || typeof input.active !== 'boolean')
        throw new StockError(400, 'Informe telefone ou e-mail válido do ponto parceiro.'); const id = input.id ?? randomUUID(); if (input.id) {
        if (!this.db.prepare('UPDATE stock_partners SET name=?,contact=?,phone=?,email=?,tax_document=?,address=?,notes=?,active=?,revision=revision+1 WHERE id=? AND revision=?').run(name, contact, phone, email, tax, address, notes, input.active ? 1 : 0, id, stockInt(input.expectedRevision, 1)).changes)
            throw new StockError(409, 'Ponto alterado.');
        this.db.prepare('UPDATE stock_locations SET name=? WHERE id=?').run(name, this.partner(id).location_id);
    }
    else {
        const location = 'partner:' + id;
        this.db.prepare("INSERT INTO stock_locations VALUES(?,?,'partner',1)").run(location, name);
        this.db.prepare('INSERT INTO stock_partners(id,name,contact,phone,email,tax_document,address,notes,location_id,active) VALUES(?,?,?,?,?,?,?,?,?,?)').run(id, name, contact, phone, email, tax, address, notes, location, input.active ? 1 : 0);
    } return { id }; }); }
    remit(input) { return this.stock.operation(input.requestKey, 'partner-remit', input.partnerId, input, () => { const partner = this.partner(input.partnerId); if (!partner.active)
        throw new StockError(409, 'Ponto inativo não recebe nova remessa.'); if (!Array.isArray(input.items) || !input.items.length || input.items.length > 50)
        throw new StockError(400, 'Confira os itens da remessa.'); const sentOn = financeDate(input.sentOn), id = randomUUID(), now = new Date().toISOString(); this.db.prepare('INSERT INTO partner_remittances VALUES(?,?,?,?,?,?)').run(id, partner.id, sentOn, JSON.stringify(partner), this.actor, now); const lines = []; for (const l of input.items) {
        const productId = stockInt(l.productId, 1), quantity = stockInt(l.quantity, 1, 1000000), repass = stockInt(l.repass, 0, 10000000000), item = this.stock.ensureOwn(productId), itemId = String(item.id);
        if (this.stock.balance(itemId, 'central') - reservedStock(this.db, itemId) < quantity)
            throw new StockError(409, 'Disponibilidade central insuficiente para a remessa.');
        const lineId = randomUUID();
        lines.push(lineId);
        this.db.prepare('INSERT INTO partner_remittance_lines VALUES(?,?,?,?,?,?)').run(lineId, id, itemId, quantity, repass, JSON.stringify(this.stock.product(productId).data));
        this.db.prepare('INSERT INTO partner_agreements VALUES(?,?,?) ON CONFLICT(partner_id,product_id) DO UPDATE SET repass=excluded.repass').run(partner.id, productId, repass);
        this.stock.move(itemId, 'central', -quantity, 'partner-remittance', lineId, 'Remessa consignada sem venda');
        this.stock.move(itemId, String(partner.location_id), quantity, 'partner-remittance', lineId, 'Remessa consignada sem venda');
    } return { id, lines }; }); }
    remittances(productId) { const rows = this.db.prepare('SELECT l.*,r.partner_id,r.sent_on,p.name partner_name,p.active partner_active,p.location_id,s.product_id FROM partner_remittance_lines l JOIN partner_remittances r ON r.id=l.remittance_id JOIN stock_partners p ON p.id=r.partner_id JOIN stock_items s ON s.id=l.item_id' + (productId ? ' WHERE s.product_id=?' : '') + ' ORDER BY r.registered_at DESC,l.rowid').all(...(productId ? [productId] : [])); return rows.map((r) => ({ ...r, remaining: Number(r.quantity) - Number(this.db.prepare('SELECT COALESCE(SUM(quantity),0) n FROM partner_events WHERE line_id=?').get(r.id).n) })); }
    partnerEvent(lineId, input) { return this.stock.operation(input.requestKey, 'partner-event', lineId, input, () => { const line = this.remittances().find(l => l.id === lineId); if (!line)
        throw new StockError(404, 'Remessa não encontrada.'); const quantity = stockInt(input.quantity, 1, 1000000), reason = stockText(input.reason, 1000); if (!['sale', 'return'].includes(input.kind) || quantity > line.remaining)
        throw new StockError(409, 'Quantidade supera o saldo do acordo.'); const id = randomUUID(), titleId = input.kind === 'sale' ? 'partner-sale:' + id : null, locationId = String(line.location_id), itemId = String(line.item_id), before = this.stock.balance(itemId, locationId); this.stock.move(itemId, locationId, -quantity, input.kind === 'sale' ? 'partner-sale' : 'partner-return', id, reason); if (input.kind === 'return')
        this.stock.move(itemId, 'central', quantity, 'partner-return', id, reason);
    else {
        const amount = safeInteger(BigInt(quantity) * BigInt(Number(line.repass)));
        if (amount > 10000000000)
            throw new StockError(400, 'Valor fora do limite.');
        this.db.prepare('INSERT INTO finance_titles(id,direction,origin,origin_id,amount_cents,description,metadata,created_at) VALUES(?,?,?,?,?,?,?,?)').run(titleId, 'in', 'partner_sale', id, amount, 'Acerto — ' + line.partner_name, JSON.stringify({ partnerId: line.partner_id, productIds: [line.product_id], lineId, quantity, repass: line.repass }), new Date().toISOString());
    } this.db.prepare('INSERT INTO partner_events VALUES(?,?,?,?,?,?,?,?)').run(id, lineId, input.kind, quantity, titleId, reason, this.actor, new Date().toISOString()); if (before < quantity)
        addAttention(this.db, this.actor, { key: 'partner:' + id, kind: 'stock-divergence', sourceKind: 'partner', sourceId: id, itemRef: itemId, locationId, quantity: quantity - Math.max(0, before), details: { name: JSON.parse(String(line.snapshot)).name, productId: line.product_id, reason }, href: '?view=estoque&productId=' + line.product_id + '&locationId=' + encodeURIComponent(locationId), priority: 'high' }); return { id, titleId }; }); }
    resolveSource(kind, sourceId, reason, itemRef) { for (const row of this.db.prepare("SELECT id FROM attention_events WHERE kind=? AND source_id=? AND state='open'" + (itemRef ? ' AND item_ref=?' : '')).all(kind, sourceId, ...(itemRef ? [itemRef] : []))) {
        const now = new Date().toISOString();
        this.db.prepare("UPDATE attention_events SET state='resolved',resolved_at=? WHERE id=?").run(now, row.id);
        this.db.prepare('INSERT INTO attention_history(attention_id,action,reason,actor,registered_at) VALUES(?,?,?,?,?)').run(row.id, 'resolved', reason, this.actor, now);
    } }
    destination(itemId, input) { return this.stock.operation(input.requestKey, 'client-destination', itemId, input, () => { const item = this.stock.item(itemId); if (item.kind !== 'client')
        throw new StockError(400, 'Item não pertence a estoque privado.'); const quantity = stockInt(input.quantity, 1, 1000000), available = this.stock.balance(itemId, 'central') - reservedStock(this.db, itemId), reason = stockText(input.reason, 1000); if (quantity > available || !['discard', 'convert'].includes(input.kind))
        throw new StockError(409, 'Quantidade supera excedente sem reserva.'); const id = randomUUID(), target = input.kind === 'convert' ? stockInt(input.targetProductId, 1) : null; if (target && input.confirmPrivacy !== true)
        throw new StockError(400, 'Confirme explicitamente a privacidade e o vínculo ao produto próprio.'); let targetItem = null; if (target)
        targetItem = String(this.stock.ensureOwn(target).id); this.stock.move(itemId, 'central', -quantity, input.kind === 'discard' ? 'client-loss' : 'client-convert', id, reason); if (targetItem)
        this.stock.move(targetItem, 'central', quantity, 'client-convert', id, reason); this.db.prepare('INSERT INTO client_destinations VALUES(?,?,?,?,?,?,?,?)').run(id, itemId, input.kind, quantity, target, reason, this.actor, new Date().toISOString()); refreshReservations(this.db); if (this.stock.balance(itemId, 'central') - reservedStock(this.db, itemId) === 0)
        this.resolveSource('client-excess', String(item.order_id), reason, itemId);
    else
        captureClientExcess(this.db, this.actor, String(item.order_id)); return { id }; }); }
}
export function registerDistribution(app, db, actor) {
    const d = new Distribution(db, actor);
    app.addHook('onReady', async () => { for (const row of db.prepare('SELECT id FROM orders').all())
        captureClientExcess(db, actor, String(row.id)); });
    const route = (fn) => async (req, reply) => { try {
        return fn(req);
    }
    catch (e) {
        return reply.code(e instanceof StockError ? e.status : e instanceof OperationConflict ? 409 : 400).send({ message: e instanceof StockError || e instanceof OperationConflict ? e.message : 'Não foi possível registrar. Confira os dados.' });
    } };
    app.get('/api/sales-places', () => db.prepare('SELECT * FROM sales_places ORDER BY name').all());
    app.post('/api/sales-places', { bodyLimit: 8192 }, route(req => d.placeSave(req.body)));
    app.get('/api/sales-sessions', () => d.sessions());
    app.post('/api/sales-sessions', { bodyLimit: 8192 }, route(req => d.openSession(req.body)));
    app.get('/api/sales-sessions/:id', route(req => d.sessionSummary(req.params.id)));
    app.post('/api/sales-sessions/:id/supply', { bodyLimit: 8192 }, route(req => d.supply(req.params.id, req.body)));
    app.post('/api/sales-sessions/:id/close', { bodyLimit: 8192 }, route(req => d.closeSession(req.params.id, req.body)));
    app.post('/api/sales-sessions/:id/expense', { bodyLimit: 8192 }, route(req => d.sessionExpense(req.params.id, req.body)));
    app.get('/api/inventory/consigned', () => d.consigned.list());
    app.post('/api/inventory/consigned', { bodyLimit: 8192 }, route(req => d.consigned.save(req.body)));
    app.post('/api/inventory/consigned/:id/receive', { bodyLimit: 8192 }, route(req => d.consigned.receive(req.params.id, req.body)));
    app.post('/api/inventory/consigned/:id/adjust', { bodyLimit: 8192 }, route(req => d.consigned.adjust(req.params.id, req.body)));
    app.get('/api/inventory/consigned/:id/history', route(req => { d.consigned.item(req.params.id); const before = (value) => value === undefined ? Number.MAX_SAFE_INTEGER : stockInt(Number(value), 1, Number.MAX_SAFE_INTEGER); const movements = db.prepare('SELECT rowid cursor,* FROM consigned_movements WHERE item_id=? AND rowid<? ORDER BY rowid DESC LIMIT 200').all(req.params.id, before(req.query.movementBefore)), receipts = db.prepare('SELECT rowid cursor,* FROM consigned_receipts WHERE item_id=? AND rowid<? ORDER BY rowid DESC LIMIT 200').all(req.params.id, before(req.query.receiptBefore)); return { movements, receipts, hasMore: movements.length === 200 || receipts.length === 200 }; }));
    app.get('/api/inventory/partners', () => db.prepare('SELECT * FROM stock_partners ORDER BY name').all());
    app.post('/api/inventory/partners', { bodyLimit: 8192 }, route(req => d.partnerSave(req.body)));
    app.get('/api/inventory/remittances', route(req => d.remittances(req.query.productId ? stockInt(Number(req.query.productId), 1) : undefined)));
    app.get('/api/inventory/partner-agreements', () => db.prepare('SELECT * FROM partner_agreements').all());
    app.post('/api/inventory/remittances', { bodyLimit: 32768 }, route(req => d.remit(req.body)));
    app.post('/api/inventory/remittances/:id/event', { bodyLimit: 8192 }, route(req => d.partnerEvent(req.params.id, req.body)));
    app.post('/api/inventory/client-stock/:id/destination', { bodyLimit: 8192 }, route(req => d.destination(req.params.id, req.body)));
    app.get('/api/operational-preferences', () => ({ preferences: db.prepare('SELECT * FROM operational_preferences WHERE id=1').get(), openSession: d.sessions().find(s => !s.financial_closed_at) ?? null }));
    app.put('/api/operational-preferences', { bodyLimit: 4096 }, route(req => d.stock.operation(req.body.requestKey, 'preferences', 'home', req.body, () => { if (!['produtos', 'clientes', 'orcamentos', 'pedidos', 'estoque', 'vendas', 'financeiro', 'configuracoes'].includes(req.body.homeView) || typeof req.body.prioritizeSales !== 'boolean')
        throw new StockError(400, 'Preferência inválida.'); if (!db.prepare('UPDATE operational_preferences SET home_view=?,prioritize_sales=?,revision=revision+1 WHERE id=1 AND revision=?').run(req.body.homeView, req.body.prioritizeSales ? 1 : 0, stockInt(req.body.expectedRevision, 1)).changes)
        throw new StockError(409, 'Preferências alteradas.'); return { saved: true }; })));
}
