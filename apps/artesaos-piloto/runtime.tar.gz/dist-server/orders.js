import { captureClientExcess } from './attention.js';
import { syncOrderFinance } from './finance-sources.js';
import { randomUUID } from 'node:crypto';
import { ProductStock, StockError, stockInt, stockText } from './product-stock.js';
import { OperationConflict } from './foundation/operations.js';
import { refreshReservations } from './stock-reservations.js';
import { quoteTotals } from './quotes.js';
import { safeInteger, parseDecimal } from './foundation/decimal.js';
export class Orders {
    db;
    actor;
    stock;
    constructor(db, actor) {
        this.db = db;
        this.actor = actor;
        this.stock = new ProductStock(db, actor);
    }
    get(orderId) { const order = this.db.prepare('SELECT * FROM orders WHERE id=?').get(stockText(orderId, 100)); if (!order)
        throw new StockError(404, 'Pedido não encontrado.'); const lines = this.db.prepare('SELECT l.*,r.item_id stock_item_id,COALESCE(r.quantity,0) reserved FROM order_lines l LEFT JOIN stock_reservations r ON r.line_id=l.id WHERE l.order_id=? AND l.active=1 ORDER BY l.rowid').all(orderId).map(line => ({ ...line, id: String(line.id), product_id: line.product_id === null ? null : Number(line.product_id), quantity: Number(line.quantity), reserved: Number(line.reserved), stock_item_id: line.stock_item_id === null ? null : String(line.stock_item_id), snapshot: JSON.parse(String(line.snapshot)), missing: Number(line.quantity) - Number(line.reserved) })); return { ...order, id: String(order.id), client_id: Number(order.client_id), revision: Number(order.revision), status: String(order.status), total_cents: Number(order.total_cents), client: JSON.parse(String(order.client_snapshot)), quoteSnapshot: order.quote_snapshot ? JSON.parse(String(order.quote_snapshot)) : null, items: lines, history: this.db.prepare('SELECT * FROM order_events WHERE order_id=? ORDER BY id DESC').all(orderId) }; }
    event(orderId, kind, snapshot) { this.db.prepare('INSERT INTO order_events(order_id,kind,snapshot,actor,registered_at) VALUES(?,?,?,?,?)').run(orderId, kind, JSON.stringify(snapshot, (key, value) => key === 'history' ? undefined : value), this.actor, new Date().toISOString()); }
    draft(draft, old, quoteItems) {
        const clientId = stockInt(draft.clientId, 1), client = this.db.prepare('SELECT data FROM clients WHERE id=?').get(clientId);
        if (!client)
            throw new StockError(400, 'Identifique o cliente do pedido.');
        if (!Array.isArray(draft.items) || !draft.items.length || draft.items.length > 200)
            throw new StockError(400, 'Inclua de um a 200 itens.');
        const ids = new Set();
        const items = draft.items.map((input, index) => {
            const previous = input.id ? old?.items.find(l => l.id === input.id) : undefined;
            if (input.id && !previous)
                throw new StockError(409, 'Item não pertence a este pedido.');
            const lineId = previous ? String(previous.id) : randomUUID();
            if (ids.has(lineId))
                throw new StockError(400, 'Item repetido.');
            ids.add(lineId);
            const productId = input.productId === null ? null : stockInt(input.productId, 1), q = quoteItems?.[index];
            let snapshot;
            if (productId) {
                const p = this.stock.product(productId).data;
                snapshot = q ? { ...p, ...q } : previous && previous.product_id === productId ? previous.snapshot : p;
            }
            else if (q)
                snapshot = q;
            else if (previous && previous.product_id === null)
                snapshot = previous.snapshot;
            else
                throw new StockError(400, 'Vincule o item ao cadastro de Produtos.');
            return { id: lineId, productId, quantity: stockInt(input.quantity, 1, 1000000), unitPrice: stockInt(input.unitPrice, 0, 10000000000), snapshot };
        });
        const extra = stockInt(draft.extraCents, 0, 10000000000), total = safeInteger(items.reduce((n, l) => n + BigInt(l.quantity) * BigInt(l.unitPrice), BigInt(extra)));
        if (total > 10000000000)
            throw new StockError(400, 'Total do pedido fora do limite.');
        const dueOn = stockText(draft.dueOn, 10, false);
        if (dueOn && (!/^\d{4}-\d{2}-\d{2}$/.test(dueOn) || !Number.isFinite(Date.parse(dueOn)) || new Date(dueOn).toISOString().slice(0, 10) !== dueOn))
            throw new StockError(400, 'Prazo inválido.');
        return { clientId, client: JSON.parse(String(client.data)), items, extra, total, dueOn: dueOn || null, notes: stockText(draft.notes, 1000, false) };
    }
    writeLines(orderId, items) { this.db.prepare('UPDATE order_lines SET active=0 WHERE order_id=?').run(orderId); for (const l of items)
        this.db.prepare('INSERT INTO order_lines(id,order_id,product_id,quantity,unit_price,snapshot) VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET product_id=excluded.product_id,quantity=excluded.quantity,unit_price=excluded.unit_price,snapshot=excluded.snapshot,active=1').run(l.id, orderId, l.productId, l.quantity, l.unitPrice, JSON.stringify(l.snapshot)); }
    create(input) {
        return this.stock.operation(input.requestKey, 'order-create', 'new', input, () => {
            let draft = input, quote = null, quoteItems;
            if (input.quoteId !== undefined) {
                const row = this.db.prepare('SELECT * FROM quotes WHERE id=? AND archived=0').get(stockInt(input.quoteId, 1));
                if (!row || row.revision !== stockInt(input.expectedQuoteRevision, 1))
                    throw new StockError(409, 'Orçamento alterado. Reabra antes de aprovar.');
                if (this.db.prepare('SELECT id FROM orders WHERE quote_id=?').get(input.quoteId))
                    throw new StockError(409, 'Este orçamento já tem pedido vinculado.');
                const data = JSON.parse(String(row.data));
                if (!['finalized', 'sent'].includes(data.status))
                    throw new StockError(400, 'Finalize a proposta antes de aprovar.');
                const totals = quoteTotals(data.items, data.delivery);
                if (totals.pending || totals.freightPending || !data.client?.id)
                    throw new StockError(400, 'Proposta incompleta.');
                quoteItems = data.items;
                draft = { clientId: Number(data.client.id), extraCents: totals.deliveryCents, notes: input.notes ?? '', dueOn: input.dueOn ?? '', items: data.items.map((l) => ({ productId: l.productId, quantity: Number(l.quantity), unitPrice: l.prices[l.priceKey] + (l.packaging === 'with' && !l.packagingIncluded ? Number(parseDecimal(l.packagingAmount, 2)) : 0) })) };
                quote = { id: input.quoteId, revision: row.revision, data, totals };
            }
            const data = this.draft(draft, undefined, quoteItems), orderId = randomUUID(), now = new Date().toISOString();
            this.db.prepare('INSERT INTO orders(id,client_id,client_snapshot,quote_id,quote_snapshot,status,total_cents,extra_cents,due_on,notes,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)').run(orderId, data.clientId, JSON.stringify(quote?.data.client ?? data.client), quote?.id ?? null, quote ? JSON.stringify(quote) : null, 'open', data.total, data.extra, data.dueOn, data.notes, now, now);
            this.writeLines(orderId, data.items);
            syncOrderFinance(this.db, orderId, this.actor);
            refreshReservations(this.db);
            this.event(orderId, 'created', this.get(orderId));
            return { id: orderId };
        });
    }
    update(orderId, input) { return this.stock.operation(input.requestKey, 'order-edit', orderId, input, () => { const before = this.get(orderId); this.editable(before, input.expectedRevision); const data = this.draft(input, before); this.db.prepare('UPDATE orders SET client_id=?,client_snapshot=?,total_cents=?,extra_cents=?,due_on=?,notes=?,revision=revision+1,updated_at=? WHERE id=?').run(data.clientId, JSON.stringify(data.client), data.total, data.extra, data.dueOn, data.notes, new Date().toISOString(), orderId); this.writeLines(orderId, data.items); syncOrderFinance(this.db, orderId, this.actor); refreshReservations(this.db); captureClientExcess(this.db, this.actor, orderId); this.event(orderId, 'edited', { before, after: this.get(orderId) }); return { id: orderId, revision: Number(before.revision) + 1 }; }); }
    editable(order, revision) { if (order.revision !== stockInt(revision, 1))
        throw new StockError(409, 'Pedido alterado. Reabra antes de continuar.'); if (['delivered', 'cancelled'].includes(String(order.status)))
        throw new StockError(409, 'Pedido entregue ou cancelado mantém histórico; não pode ser editado.'); }
    transition(orderId, input) {
        return this.stock.operation(input.requestKey, 'order-status', orderId, input, () => {
            const before = this.get(orderId);
            this.editable(before, input.expectedRevision);
            if (!['production', 'ready', 'delivered', 'cancelled'].includes(input.status))
                throw new StockError(400, 'Situação inválida.');
            const reason = stockText(input.reason, 1000);
            if (['ready', 'delivered'].includes(input.status) && before.items.some(l => l.missing > 0))
                throw new StockError(409, 'Há unidades faltando. Fabrique ou confira o estoque antes da entrega.');
            this.db.prepare('UPDATE orders SET status=?,revision=revision+1,updated_at=? WHERE id=?').run(input.status, new Date().toISOString(), orderId);
            if (input.status === 'delivered')
                for (const line of before.items) {
                    const held = line.stock_item_id;
                    if (!held || this.stock.balance(String(held), 'central') < Number(line.quantity))
                        throw new StockError(409, 'Estoque mudou antes da entrega.');
                    this.stock.move(String(held), 'central', -Number(line.quantity), 'order-delivery', orderId, 'Entrega integral do pedido');
                }
            syncOrderFinance(this.db, orderId, this.actor);
            refreshReservations(this.db);
            captureClientExcess(this.db, this.actor, orderId);
            this.event(orderId, input.status, { before, reason });
            return { id: orderId, status: input.status };
        });
    }
}
export function registerOrders(app, db, actor) {
    const orders = new Orders(db, actor);
    const route = (fn) => async (req, reply) => { try {
        return fn(req);
    }
    catch (e) {
        return reply.code(e instanceof StockError ? e.status : e instanceof OperationConflict ? 409 : 400).send({ message: e instanceof StockError || e instanceof OperationConflict ? e.message : 'Não foi possível registrar o pedido. Confira os dados.' });
    } };
    app.get('/api/orders', () => db.prepare('SELECT id FROM orders ORDER BY created_at DESC,rowid DESC').all().map(row => orders.get(String(row.id))));
    app.get('/api/orders/:id', route(req => orders.get(req.params.id)));
    app.post('/api/orders', { bodyLimit: 262144 }, route(req => orders.create(req.body)));
    app.put('/api/orders/:id', { bodyLimit: 262144 }, route(req => orders.update(req.params.id, req.body)));
    app.post('/api/orders/:id/status', { bodyLimit: 8192 }, route(req => orders.transition(req.params.id, req.body)));
}
