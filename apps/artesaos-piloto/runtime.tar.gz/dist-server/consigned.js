import { photoReferenceAllowed, PHOTO_REFERENCE_ERROR } from './product-photos.js';
import { matchesStockAttention, closeAttention } from './attention.js';
import { randomUUID } from 'node:crypto';
import { ProductStock, StockError, stockInt, stockText } from './product-stock.js';
import { financeDate, today } from './finance.js';
import { safeInteger } from './foundation/decimal.js';
export class Consigned {
    db;
    actor;
    stock;
    constructor(db, actor) {
        this.db = db;
        this.actor = actor;
        this.stock = new ProductStock(db, actor);
    }
    item(itemId) { const row = this.db.prepare('SELECT * FROM consigned_items WHERE id=?').get(stockText(itemId, 100)); if (!row)
        throw new StockError(404, 'Consignado não encontrado.'); return row; }
    balance(itemId, locationId, receiptId) { return Number(this.db.prepare('SELECT COALESCE(SUM(delta),0) n FROM consigned_movements WHERE item_id=?' + (locationId ? ' AND location_id=?' : '') + (receiptId === undefined ? '' : receiptId === null ? ' AND receipt_id IS NULL' : ' AND receipt_id=?')).get(itemId, ...(locationId ? [locationId] : []), ...(typeof receiptId === 'string' ? [receiptId] : [])).n); }
    list() { return this.db.prepare('SELECT * FROM consigned_items ORDER BY rowid DESC').all().map(r => ({ ...r, id: String(r.id), total: this.balance(String(r.id)), inHand: this.balance(String(r.id), 'central'), locations: this.db.prepare('SELECT l.id,l.name,l.active,COALESCE(SUM(m.delta),0) quantity FROM stock_locations l LEFT JOIN consigned_movements m ON m.location_id=l.id AND m.item_id=? GROUP BY l.id').all(r.id) })); }
    save(input) { return this.stock.operation(input.requestKey, 'consigned-save', input.id ?? 'new', input, () => { const name = stockText(input.name, 200), supplier = stockText(input.supplier, 200), price = stockInt(input.salePrice, 0, 10000000000), repass = stockInt(input.repass, 0, 10000000000), image = stockText(input.imageUrl, 2048, false); if (typeof input.active !== 'boolean')
        throw new StockError(400, 'Confira a situação.'); if (!photoReferenceAllowed(this.db, image, input.id ? String(this.item(input.id).image_url) : undefined))
        throw new StockError(400, PHOTO_REFERENCE_ERROR); const id = input.id ?? randomUUID(); if (input.id) {
        const old = this.item(id);
        if (old.revision !== stockInt(input.expectedRevision, 1))
            throw new StockError(409, 'Consignado alterado.');
        if (supplier !== old.supplier && this.db.prepare('SELECT 1 FROM consigned_receipts WHERE item_id=? LIMIT 1').get(id))
            throw new StockError(409, 'Fornecedor com histórico deve ser preservado. Cadastre outro item para outro fornecedor.');
        this.db.prepare('UPDATE consigned_items SET name=?,supplier=?,sale_price=?,repass=?,image_url=?,active=?,revision=revision+1 WHERE id=?').run(name, supplier, price, repass, image, input.active ? 1 : 0, id);
    }
    else
        this.db.prepare('INSERT INTO consigned_items(id,name,supplier,sale_price,repass,image_url,active) VALUES(?,?,?,?,?,?,?)').run(id, name, supplier, price, repass, image, input.active ? 1 : 0); return { id }; }); }
    move(itemId, locationId, receiptId, delta, kind, source, reason) { this.stock.location(locationId); const before = this.balance(itemId, locationId), after = safeInteger(BigInt(before) + BigInt(delta)); safeInteger(BigInt(this.balance(itemId)) + BigInt(delta)); this.db.prepare('INSERT INTO consigned_movements(item_id,receipt_id,location_id,delta,before_qty,after_qty,kind,source_id,reason,actor,registered_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)').run(itemId, receiptId, locationId, delta, before, after, kind, source, reason, this.actor, new Date().toISOString()); }
    receipt(itemId, quantity, repass, receivedOn, label, reason, locationId = 'central') { const item = this.item(itemId); if (!item.active)
        throw new StockError(409, 'Item inativo não recebe novas remessas.'); const id = randomUUID(); this.db.prepare('INSERT INTO consigned_receipts VALUES(?,?,?,?,?,?,?,?,?)').run(id, itemId, quantity, repass, receivedOn, label, JSON.stringify({ item, reason }), this.actor, new Date().toISOString()); this.move(itemId, locationId, id, quantity, 'receipt', id, reason); return id; }
    receive(itemId, input) { return this.stock.operation(input.requestKey, 'consigned-receive', itemId, input, () => ({ receiptId: this.receipt(itemId, stockInt(input.quantity, 1, 1000000), stockInt(input.repass, 0, 10000000000), financeDate(input.receivedOn), stockText(input.label, 100, false), stockText(input.reason, 1000)) })); }
    take(itemId, locationId, quantity, kind, source, reason, allowDeficit) { const item = this.item(itemId), before = this.balance(itemId, locationId); let remaining = quantity, owed = 0n; const allocations = []; const lots = this.db.prepare('SELECT r.* FROM consigned_receipts r WHERE r.item_id=? ORDER BY r.received_on,r.registered_at,r.rowid').all(itemId); for (const lot of lots) {
        const use = Math.min(remaining, Math.max(0, this.balance(itemId, locationId, String(lot.id))));
        if (!use)
            continue;
        remaining -= use;
        owed += BigInt(use) * BigInt(Number(lot.repass));
        allocations.push({ receiptId: String(lot.id), quantity: use, repass: Number(lot.repass) });
        this.move(itemId, locationId, String(lot.id), -use, kind, source, reason);
        if (!remaining)
            break;
    } if (remaining) {
        if (!allowDeficit)
            throw new StockError(409, 'Saldo insuficiente para transferência.');
        owed += BigInt(remaining) * BigInt(Number(item.repass));
        allocations.push({ receiptId: null, quantity: remaining, repass: Number(item.repass) });
        this.move(itemId, locationId, null, -remaining, kind, source, reason);
    } const total = safeInteger(owed); if (total > 10000000000)
        throw new StockError(400, 'Repasse total fora do limite.'); return { before, owed: total, allocations }; }
    transfer(itemId, from, to, quantity, source, reason) { this.item(itemId); if (from === to || this.balance(itemId, from) < quantity)
        throw new StockError(409, 'Confira locais e saldo da transferência.'); const result = this.take(itemId, from, quantity, 'transfer', source, reason, false); for (const a of result.allocations)
        this.move(itemId, to, a.receiptId, a.quantity, 'transfer', source, reason); return { total: this.balance(itemId) }; }
    sale(itemId, locationId, quantity, saleId, line, netSale, sessionId = null) { const item = this.item(itemId), source = saleId + ':' + line, result = this.take(itemId, locationId, quantity, 'sale', source, 'Venda de consignado', true), titleId = 'consigned:' + source; this.db.prepare('INSERT INTO finance_titles(id,direction,origin,origin_id,amount_cents,description,metadata,created_at) VALUES(?,?,?,?,?,?,?,?)').run(titleId, 'out', 'consigned', source, result.owed, 'Repasse — ' + item.supplier, JSON.stringify({ saleId, sessionId, consignedIds: [itemId], supplier: item.supplier, quantity, netSaleCents: netSale, allocations: result.allocations }), new Date().toISOString()); return { ...result, titleId }; }
    adjust(itemId, input) { return this.stock.operation(input.requestKey, 'consigned-adjust', itemId, input, () => { const item = this.item(itemId), locationId = input.locationId ?? 'central'; this.stock.location(locationId); const before = this.balance(itemId, locationId); if (before !== stockInt(input.expectedBalance, -1000000000))
        throw new StockError(409, 'Saldo alterado.'); const after = stockInt(input.newBalance, 0, 1000000), reason = stockText(input.reason, 1000), delta = after - before; if (delta < 0)
        this.take(itemId, locationId, -delta, 'correction', input.requestKey, reason, false);
    else if (delta > 0) {
        const deficit = Math.max(0, -this.balance(itemId, locationId, null)), fix = Math.min(delta, deficit);
        if (fix)
            this.move(itemId, locationId, null, fix, 'correction', input.requestKey, reason);
        if (delta > fix)
            this.receipt(itemId, delta - fix, Number(item.repass), today(), 'Inventário', reason, locationId);
    } if (input.attentionId) {
        if (!matchesStockAttention(this.db, stockText(input.attentionId, 100), itemId, locationId, 'consigned'))
            throw new StockError(409, 'Pendência não corresponde ao consignado/local.');
        closeAttention(this.db, this.actor, input.attentionId, 'Conferência consignada: ' + reason);
    } return { balance: after }; }); }
}
