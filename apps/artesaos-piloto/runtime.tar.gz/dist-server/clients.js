import { clientSchema as schema, normalizeClient } from './client-data.js';
export function registerClients(app, db) {
    app.get('/api/clients', () => db.prepare('SELECT id,data,updated_at FROM clients WHERE archived=0 ORDER BY id DESC').all().map(row => ({ id: row.id, ...normalizeClient(JSON.parse(row.data)), updatedAt: row.updated_at })));
    app.post('/api/clients', { bodyLimit: 8192, schema: { body: schema } }, req => {
        const data = normalizeClient(req.body);
        const result = db.prepare('INSERT INTO clients(data,updated_at) VALUES (?,?)').run(JSON.stringify(data), new Date().toISOString());
        return { id: Number(result.lastInsertRowid) };
    });
    app.put('/api/clients/:id', { bodyLimit: 8192, schema: { body: schema } }, (req, reply) => {
        const result = db.prepare('UPDATE clients SET data=?,updated_at=? WHERE id=? AND archived=0').run(JSON.stringify(normalizeClient(req.body)), new Date().toISOString(), req.params.id);
        return result.changes ? { ok: true } : reply.code(404).send({ message: 'Cliente não encontrado.' });
    });
    app.delete('/api/clients/:id', (req, reply) => {
        const result = db.prepare('UPDATE clients SET archived=1 WHERE id=? AND archived=0').run(req.params.id);
        return result.changes ? { ok: true } : reply.code(404).send({ message: 'Cliente não encontrado.' });
    });
}
