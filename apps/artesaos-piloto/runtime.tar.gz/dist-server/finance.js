import { financialAttention } from './attention.js';
import { randomUUID, createHash } from 'node:crypto';
import { ProductStock, StockError, stockInt, stockText } from './product-stock.js';
import { OperationConflict } from './foundation/operations.js';
import { divideRounded, safeInteger } from './foundation/decimal.js';
export const today = () => new Date().toISOString().slice(0, 10);
export function financeDate(value) { const s = stockText(value, 10); if (!/^\d{4}-\d{2}-\d{2}$/.test(s) || !Number.isFinite(Date.parse(s)) || new Date(s).toISOString().slice(0, 10) !== s)
    throw new StockError(400, 'Data inválida.'); return s; }
const money = (v, positive = false) => stockInt(v, positive ? 1 : 0, 10000000000);
export class Finance {
    db;
    actor;
    stock;
    constructor(db, actor) {
        this.db = db;
        this.actor = actor;
        this.stock = new ProductStock(db, actor);
    }
    operation(key, action, source, input, work) { return this.stock.operation(key, 'finance-' + action, source, input, work); }
    account(accountId) { const row = this.db.prepare('SELECT * FROM finance_accounts WHERE id=? AND active=1').get(stockText(accountId, 100)); if (!row)
        throw new StockError(404, 'Conta não encontrada ou inativa.'); return row; }
    accountBalance(accountId) { return Number(this.db.prepare('SELECT COALESCE(SUM(cash_cents),0) n FROM finance_entries WHERE account_id=?').get(accountId).n); }
    title(titleId) { const t = this.db.prepare('SELECT * FROM finance_titles WHERE id=?').get(stockText(titleId, 150)); if (!t)
        throw new StockError(404, 'Lançamento não encontrado.'); const allocated = Number(this.db.prepare('SELECT COALESCE(SUM(allocation_cents),0) n FROM finance_entries WHERE title_id=?').get(titleId).n), scheduled = Number(this.db.prepare("SELECT COALESCE(SUM(amount_cents),0) n FROM finance_payments WHERE title_id=? AND state='scheduled'").get(titleId).n), remaining = Number(t.amount_cents) - allocated; return { ...t, id: String(t.id), origin: String(t.origin), due_on: t.due_on === null ? null : String(t.due_on), created_at: String(t.created_at), direction: String(t.direction), client_id: t.client_id === null ? null : Number(t.client_id), amount_cents: Number(t.amount_cents), revision: Number(t.revision), metadata: JSON.parse(String(t.metadata)), allocated, scheduled, remaining, status: remaining < 0 ? 'excess' : remaining === 0 ? 'paid' : allocated > 0 ? 'partial' : 'pending' }; }
    entry(input) { if (input.accountId) {
        this.account(input.accountId);
        safeInteger(BigInt(this.accountBalance(input.accountId)) + BigInt(input.cash));
    } if (input.titleId)
        safeInteger(BigInt(this.title(input.titleId).allocated) + BigInt(input.allocation)); const id = randomUUID(); this.db.prepare('INSERT INTO finance_entries(id,title_id,account_id,allocation_cents,cash_cents,fee_cents,kind,source_id,payment_id,snapshot,actor,registered_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)').run(id, input.titleId, input.accountId, input.allocation, input.cash, input.fee ?? 0, input.kind, input.sourceId, input.paymentId ?? null, JSON.stringify(input.snapshot), this.actor, new Date().toISOString()); if (input.titleId)
        financialAttention(this.db, this.actor, input.titleId); return id; }
    createTitle(input) { return this.operation(input.requestKey, 'manual', 'new', input, () => { if (!['in', 'out'].includes(input.direction))
        throw new StockError(400, 'Escolha receita ou despesa.'); const amount = money(input.amountCents), description = stockText(input.description, 200), dueOn = input.dueOn ? financeDate(input.dueOn) : null, clientId = input.clientId === null ? null : stockInt(input.clientId, 1); if (clientId && !this.db.prepare('SELECT 1 FROM clients WHERE id=?').get(clientId))
        throw new StockError(400, 'Cliente não encontrado.'); const id = randomUUID(); this.db.prepare('INSERT INTO finance_titles(id,direction,origin,origin_id,amount_cents,due_on,client_id,description,metadata,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)').run(id, input.direction, 'manual', id, amount, dueOn, clientId, description, '{}', new Date().toISOString()); this.entry({ titleId: id, accountId: null, allocation: 0, cash: 0, kind: 'title-created', sourceId: id, snapshot: input }); return { id }; }); }
    pay(titleId, input) {
        return this.operation(input.requestKey, 'payment', titleId, input, () => {
            const title = this.title(titleId);
            if (title.revision !== stockInt(input.expectedRevision, 1))
                throw new StockError(409, 'Lançamento alterado. Reabra antes de pagar.');
            if (!Array.isArray(input.parts) || input.parts.length < 1 || input.parts.length > 20 || typeof input.allowExcess !== 'boolean')
                throw new StockError(400, 'Confira os pagamentos divididos.');
            const total = safeInteger(input.parts.reduce((n, p) => n + BigInt(money(p.amountCents, true)), 0n));
            if (total > 10000000000)
                throw new StockError(400, 'Pagamento fora do limite.');
            if (total > title.remaining - title.scheduled && !input.allowExcess)
                throw new StockError(409, 'Pagamento excede saldo livre de agendamentos. Revise ou autorize excedente explicitamente.');
            const paymentIds = [];
            for (const part of input.parts) {
                const method = this.db.prepare('SELECT * FROM finance_methods WHERE id=?').get(stockText(part.methodId, 50));
                if (!method)
                    throw new StockError(400, 'Forma de pagamento inválida.');
                this.account(part.accountId);
                const amount = money(part.amountCents, true), fee = part.feeCents === undefined ? safeInteger(divideRounded(BigInt(amount) * BigInt(Number(method.fee_bps)), 10000n)) + Number(method.fixed_fee) : money(part.feeCents);
                if (fee > 10000000000 || title.direction === 'in' && fee > amount)
                    throw new StockError(400, 'Taxa supera o valor recebido.');
                const expectedOn = part.expectedOn ? financeDate(part.expectedOn) : new Date(Date.now() + Number(method.delay_days) * 86400000).toISOString().slice(0, 10), settle = part.settleNow ?? expectedOn <= today();
                if (typeof settle !== 'boolean' || settle && expectedOn > today())
                    throw new StockError(400, 'Recebimento futuro deve permanecer agendado até a liquidação.');
                const id = randomUUID();
                paymentIds.push(id);
                this.db.prepare('INSERT INTO finance_payments(id,title_id,account_id,method_id,amount_cents,fee_cents,expected_on,state,snapshot,actor,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)').run(id, titleId, part.accountId, part.methodId, amount, fee, expectedOn, settle ? 'settled' : 'scheduled', JSON.stringify({ method, part }), this.actor, new Date().toISOString());
                if (settle)
                    this.recordPayment(id);
                else
                    this.entry({ titleId, accountId: null, allocation: 0, cash: 0, kind: 'scheduled', sourceId: id, paymentId: id, snapshot: { amount, fee, expectedOn, method } });
            }
            return { paymentIds };
        });
    }
    recordPayment(paymentId) { const p = this.db.prepare('SELECT * FROM finance_payments WHERE id=?').get(paymentId); const title = this.title(String(p.title_id)), amount = Number(p.amount_cents), fee = Number(p.fee_cents), cash = title.direction === 'in' ? amount - fee : -amount - fee; return this.entry({ titleId: title.id, accountId: String(p.account_id), allocation: amount, cash, fee, kind: 'payment', sourceId: paymentId, paymentId, snapshot: p }); }
    settle(paymentId, input) { return this.operation(input.requestKey, 'settlement', paymentId, input, () => { const p = this.db.prepare('SELECT * FROM finance_payments WHERE id=?').get(stockText(paymentId, 100)); if (!p)
        throw new StockError(404, 'Pagamento não encontrado.'); if (p.state !== 'scheduled')
        throw new StockError(409, 'Este agendamento já foi tratado.'); if (!['settle', 'cancel'].includes(input.action))
        throw new StockError(400, 'Ação inválida.'); const reason = stockText(input.reason, 1000); this.db.prepare('UPDATE finance_payments SET state=? WHERE id=?').run(input.action === 'settle' ? 'settled' : 'cancelled', paymentId); if (input.action === 'settle')
        this.recordPayment(paymentId); this.entry({ titleId: String(p.title_id), accountId: null, allocation: 0, cash: 0, kind: input.action === 'settle' ? 'settlement-confirmed' : 'schedule-cancelled', sourceId: paymentId, paymentId, snapshot: { reason } }); return { state: input.action === 'settle' ? 'settled' : 'cancelled' }; }); }
    refund(paymentId, input) { return this.operation(input.requestKey, 'refund', paymentId, input, () => { const p = this.db.prepare("SELECT * FROM finance_payments WHERE id=? AND state='settled'").get(stockText(paymentId, 100)); if (!p)
        throw new StockError(404, 'Pagamento liquidado não encontrado.'); const title = this.title(String(p.title_id)), amount = money(input.amountCents, true), feeRefund = money(input.feeRefundCents), previous = this.db.prepare("SELECT COALESCE(SUM(-allocation_cents),0) amount,COALESCE(SUM(-fee_cents),0) fee FROM finance_entries WHERE payment_id=? AND kind='refund'").get(paymentId); if (amount > Number(p.amount_cents) - Number(previous.amount) || amount > title.allocated || feeRefund > Number(p.fee_cents) - Number(previous.fee))
        throw new StockError(409, 'Reembolso supera o valor disponível; confira créditos e estornos anteriores.'); this.account(input.accountId); const reason = stockText(input.reason, 1000); const cash = title.direction === 'in' ? -amount + feeRefund : amount + feeRefund; const id = this.entry({ titleId: title.id, accountId: input.accountId, allocation: -amount, cash, fee: -feeRefund, kind: 'refund', sourceId: input.requestKey, paymentId, snapshot: { reason, amount, feeRefund, stockEffect: 'none' } }); return { id }; }); }
    issueCredit(titleId, input) { return this.operation(input.requestKey, 'credit-issue', titleId, input, () => { const title = this.title(titleId), amount = money(input.amountCents, true); if (title.direction !== 'in' || !title.client_id || amount > Math.max(0, -title.remaining))
        throw new StockError(409, 'Crédito exige cliente e excedente efetivamente recebido.'); const reason = stockText(input.reason, 1000), creditId = randomUUID(), entryId = this.entry({ titleId, accountId: null, allocation: -amount, cash: 0, kind: 'credit-issued', sourceId: creditId, snapshot: { reason, creditId, clientId: title.client_id } }); this.db.prepare('INSERT INTO finance_credits VALUES(?,?,?,?,?)').run(creditId, title.client_id, entryId, amount, new Date().toISOString()); return { creditId }; }); }
    credits() { return this.db.prepare('SELECT c.*,c.amount_cents-COALESCE(SUM(u.amount_cents),0) remaining FROM finance_credits c LEFT JOIN finance_credit_uses u ON u.credit_id=c.id GROUP BY c.id ORDER BY c.created_at').all(); }
    useCredit(titleId, input) { return this.operation(input.requestKey, 'credit-use', titleId, input, () => { const title = this.title(titleId), amount = money(input.amountCents, true), credit = this.credits().find(c => c.id === input.creditId); if (!credit || title.direction !== 'in' || credit.client_id !== title.client_id || amount > Number(credit.remaining) || amount > title.remaining - title.scheduled)
        throw new StockError(409, 'Crédito indisponível ou de outro cliente; confira agendamentos e saldo.'); const id = randomUUID(), entryId = this.entry({ titleId, accountId: null, allocation: amount, cash: 0, kind: 'credit-used', sourceId: id, snapshot: { creditId: input.creditId, amount } }); this.db.prepare('INSERT INTO finance_credit_uses VALUES(?,?,?,?)').run(id, input.creditId, entryId, amount); return { id }; }); }
    transfer(input) { return this.operation(input.requestKey, 'transfer', 'accounts', input, () => { this.account(input.from); this.account(input.to); if (input.from === input.to)
        throw new StockError(400, 'Escolha contas diferentes.'); const amount = money(input.amountCents, true), reason = stockText(input.reason, 1000), id = randomUUID(); for (const [accountId, sign] of [[input.from, -1], [input.to, 1]])
        this.entry({ titleId: null, accountId, allocation: 0, cash: sign * amount, kind: 'transfer', sourceId: id + ':' + sign, snapshot: { id, from: input.from, to: input.to, reason } }); return { id }; }); }
    accountSave(input) { return this.operation(input.requestKey, 'account', input.id ?? 'new', input, () => { const name = stockText(input.name, 100); if (typeof input.active !== 'boolean')
        throw new StockError(400, 'Situação da conta inválida.'); const id = input.id ? stockText(input.id, 100) : randomUUID(); if (id === 'general' && !input.active)
        throw new StockError(400, 'Caixa Geral deve permanecer disponível.'); if (input.id) {
        if (!this.db.prepare('UPDATE finance_accounts SET name=?,active=? WHERE id=?').run(name, input.active ? 1 : 0, id).changes)
            throw new StockError(404, 'Conta não encontrada.');
    }
    else
        this.db.prepare('INSERT INTO finance_accounts VALUES(?,?,?)').run(id, name, input.active ? 1 : 0); return { id }; }); }
    methodSave(input) { return this.operation(input.requestKey, 'method', input.id, input, () => { const changed = this.db.prepare('UPDATE finance_methods SET fee_bps=?,fixed_fee=?,delay_days=?,revision=revision+1 WHERE id=? AND revision=?').run(stockInt(input.feeBps, 0, 10000), money(input.fixedFee), stockInt(input.delayDays, 0, 365), stockText(input.id, 50), stockInt(input.expectedRevision, 1)); if (!changed.changes)
        throw new StockError(409, 'Forma de pagamento alterada ou não encontrada.'); return { saved: true }; }); }
    generateCurrent() { const active = this.db.prepare('SELECT id,revision FROM finance_recurring WHERE active=1 ORDER BY id').all(); if (!active.length)
        return; const month = today().slice(0, 7), revision = createHash('sha256').update(JSON.stringify(active)).digest('hex').slice(0, 32); this.generate({ requestKey: 'recurring-auto:' + month + ':' + revision, competence: month }); }
    recurringSave(input) { return this.operation(input.requestKey, 'recurring', input.id ?? 'new', input, () => { const description = stockText(input.description, 200), amount = money(input.amountCents), day = stockInt(input.dueDay, 1, 31); if (typeof input.active !== 'boolean')
        throw new StockError(400, 'Situação inválida.'); const id = input.id ?? randomUUID(); if (input.id) {
        if (!this.db.prepare('UPDATE finance_recurring SET description=?,amount_cents=?,due_day=?,active=?,revision=revision+1 WHERE id=? AND revision=?').run(description, amount, day, input.active ? 1 : 0, id, stockInt(input.expectedRevision, 1)).changes)
            throw new StockError(409, 'Recorrência alterada.');
    }
    else
        this.db.prepare('INSERT INTO finance_recurring(id,description,amount_cents,due_day,active) VALUES(?,?,?,?,?)').run(id, description, amount, day, input.active ? 1 : 0); this.generateCurrent(); return { id }; }); }
    generate(input) { return this.operation(input.requestKey, 'generate', input.competence, input, () => { const month = stockText(input.competence, 7); if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(month))
        throw new StockError(400, 'Competência inválida.'); const lastDay = new Date(Date.UTC(Number(month.slice(0, 4)), Number(month.slice(5)), 0)).getUTCDate(); let created = 0; for (const r of this.db.prepare('SELECT * FROM finance_recurring WHERE active=1').all()) {
        const source = String(r.id) + ':' + month, id = 'recurring:' + source, due = month + '-' + String(Math.min(lastDay, Number(r.due_day))).padStart(2, '0');
        const result = this.db.prepare("INSERT INTO finance_titles(id,direction,origin,origin_id,amount_cents,due_on,description,metadata,created_at) VALUES(?,'out','recurring',?,?,?,?,?,?) ON CONFLICT(origin,origin_id) DO NOTHING").run(id, source, r.amount_cents, due, r.description, JSON.stringify({ recurringId: r.id, competence: month }), new Date().toISOString());
        created += Number(result.changes);
        if (result.changes)
            this.entry({ titleId: id, accountId: null, allocation: 0, cash: 0, kind: 'title-created', sourceId: id, snapshot: { recurring: r, competence: month } });
    } return { created }; }); }
    adjustTitle(titleId, input) { return this.operation(input.requestKey, 'title-adjust', titleId, input, () => { const before = this.title(titleId); if (before.revision !== stockInt(input.expectedRevision, 1))
        throw new StockError(409, 'Lançamento alterado.'); if (!['manual', 'recurring'].includes(String(before.origin)))
        throw new StockError(400, 'Ajuste a operação de origem para preservar seus valores.'); const amount = money(input.amountCents), dueOn = input.dueOn ? financeDate(input.dueOn) : null, reason = stockText(input.reason, 1000); this.db.prepare('UPDATE finance_titles SET amount_cents=?,due_on=?,revision=revision+1 WHERE id=?').run(amount, dueOn, titleId); this.entry({ titleId, accountId: null, allocation: 0, cash: 0, kind: 'title-change', sourceId: input.requestKey, snapshot: { before, amount, dueOn, reason } }); return { saved: true }; }); }
    list(filters = {}) {
        const from = filters.from ? financeDate(filters.from) : null, to = filters.to ? financeDate(filters.to) : null, origin = filters.origin ? stockText(filters.origin, 50) : '', clientId = filters.clientId ? stockInt(Number(filters.clientId), 1) : null;
        return this.db.prepare('SELECT id FROM finance_titles ORDER BY created_at DESC,rowid DESC').all().map(row => this.title(String(row.id))).filter(t => (!origin || t.origin === origin) && (!clientId || t.client_id === clientId) && (!from || String(t.due_on ?? String(t.created_at).slice(0, 10)) >= from) && (!to || String(t.due_on ?? String(t.created_at).slice(0, 10)) <= to) && ['productId', 'materialId', 'consignedId', 'orderId', 'partnerId', 'sessionId'].every(key => !filters[key] || (Array.isArray(t.metadata[key === 'productId' ? 'productIds' : key === 'materialId' ? 'materialIds' : key === 'consignedId' ? 'consignedIds' : key]) ? t.metadata[key === 'productId' ? 'productIds' : key === 'materialId' ? 'materialIds' : key === 'consignedId' ? 'consignedIds' : key].map(String).includes(String(filters[key])) : String(t.metadata[key]) === String(filters[key]))));
    }
    summary(filters = {}) { const titles = this.list(filters), ids = new Set(this.list({ ...filters, from: undefined, to: undefined }).map(t => t.id)), from = filters.from ? financeDate(filters.from) : null, to = filters.to ? financeDate(filters.to) : null; const entries = this.db.prepare("SELECT e.*,t.direction FROM finance_entries e LEFT JOIN finance_titles t ON t.id=e.title_id WHERE e.kind!='transfer'").all().filter(e => e.title_id && ids.has(String(e.title_id)) && (!from || String(e.registered_at).slice(0, 10) >= from) && (!to || String(e.registered_at).slice(0, 10) <= to)); return { received: entries.filter(e => e.direction === 'in').reduce((n, e) => n + Number(e.cash_cents), 0), paid: entries.filter(e => e.direction === 'out').reduce((n, e) => n - Number(e.cash_cents), 0), receivable: titles.filter(t => t.direction === 'in').reduce((n, t) => n + Math.max(0, t.remaining), 0), payable: titles.filter(t => t.direction === 'out').reduce((n, t) => n + Math.max(0, t.remaining), 0), scheduled: titles.reduce((n, t) => n + t.scheduled, 0), excess: titles.reduce((n, t) => n + Math.max(0, -t.remaining), 0), fees: entries.reduce((n, e) => n + Number(e.fee_cents), 0), credits: this.credits().filter(c => !filters.clientId || Number(c.client_id) === Number(filters.clientId)).reduce((n, c) => n + Number(c.remaining), 0) }; }
}
export function registerFinance(app, db, actor) {
    const finance = new Finance(db, actor);
    let recurrenceTimer;
    app.addHook('onReady', async () => { finance.generateCurrent(); recurrenceTimer = setInterval(() => { try {
        finance.generateCurrent();
    }
    catch {
        app.log.warn('Geração de recorrências pendente; consulte o Financeiro.');
    } }, 60000); recurrenceTimer.unref(); });
    app.addHook('onClose', async () => { if (recurrenceTimer)
        clearInterval(recurrenceTimer); });
    const route = (fn) => async (req, reply) => { try {
        return fn(req);
    }
    catch (e) {
        return reply.code(e instanceof StockError ? e.status : e instanceof OperationConflict ? 409 : 400).send({ message: e instanceof StockError || e instanceof OperationConflict ? e.message : 'Não foi possível registrar a operação financeira. Confira os dados.' });
    } };
    app.get('/api/finance/titles', route(req => finance.list(req.query)));
    app.get('/api/finance/summary', route(req => finance.summary(req.query)));
    app.get('/api/finance/titles/:id', route(req => ({ title: finance.title(req.params.id), payments: db.prepare('SELECT * FROM finance_payments WHERE title_id=? ORDER BY created_at').all(req.params.id), entries: db.prepare('SELECT * FROM finance_entries WHERE title_id=? ORDER BY registered_at').all(req.params.id) })));
    app.post('/api/finance/titles', { bodyLimit: 8192 }, route(req => finance.createTitle(req.body)));
    app.put('/api/finance/titles/:id', { bodyLimit: 8192 }, route(req => finance.adjustTitle(req.params.id, req.body)));
    app.post('/api/finance/titles/:id/payments', { bodyLimit: 32768 }, route(req => finance.pay(req.params.id, req.body)));
    app.post('/api/finance/payments/:id/settle', { bodyLimit: 8192 }, route(req => finance.settle(req.params.id, req.body)));
    app.post('/api/finance/payments/:id/refund', { bodyLimit: 8192 }, route(req => finance.refund(req.params.id, req.body)));
    app.post('/api/finance/titles/:id/credit', { bodyLimit: 8192 }, route(req => finance.issueCredit(req.params.id, req.body)));
    app.post('/api/finance/titles/:id/use-credit', { bodyLimit: 8192 }, route(req => finance.useCredit(req.params.id, req.body)));
    app.get('/api/finance/credits', () => finance.credits());
    app.get('/api/finance/accounts', () => db.prepare('SELECT * FROM finance_accounts ORDER BY rowid').all().map(r => ({ ...r, balance: finance.accountBalance(String(r.id)) })));
    app.post('/api/finance/accounts', { bodyLimit: 4096 }, route(req => finance.accountSave(req.body)));
    app.post('/api/finance/transfers', { bodyLimit: 4096 }, route(req => finance.transfer(req.body)));
    app.get('/api/finance/methods', () => db.prepare('SELECT * FROM finance_methods ORDER BY rowid').all());
    app.put('/api/finance/methods/:id', { bodyLimit: 4096 }, route(req => finance.methodSave({ ...req.body, id: req.params.id })));
    app.get('/api/finance/recurring', () => db.prepare('SELECT * FROM finance_recurring ORDER BY rowid').all());
    app.post('/api/finance/recurring', { bodyLimit: 8192 }, route(req => finance.recurringSave(req.body)));
    app.post('/api/finance/generate', { bodyLimit: 4096 }, route(req => finance.generate(req.body)));
    app.get('/api/finance/analysis', route(req => {
        const filters = req.query, from = filters.from ? financeDate(filters.from) : null, to = filters.to ? financeDate(filters.to) : null;
        const inPeriod = (value) => (!from || String(value).slice(0, 10) >= from) && (!to || String(value).slice(0, 10) <= to);
        const losses = db.prepare("SELECT * FROM material_movements WHERE kind IN ('loss','close')").all().filter(r => inPeriod(r.registered_at) && (!filters.materialId || Number(r.material_id) === stockInt(Number(filters.materialId), 1)) && !['productId', 'orderId', 'clientId', 'partnerId', 'sessionId'].some(key => filters[key]));
        const loss = { cents: losses.reduce((n, r) => n + Number(r.analytical_cents ?? 0), 0), unknown: losses.filter(r => r.analytical_cents === null).length };
        const production = db.prepare('SELECT m.*,o.client_id FROM completed_manufacturing m LEFT JOIN orders o ON o.id=m.order_id').all().filter(r => inPeriod(r.registered_at) && (!filters.productId || Number(r.product_id) === stockInt(Number(filters.productId), 1)) && (!filters.orderId || r.order_id === filters.orderId) && (!filters.clientId || Number(r.client_id) === stockInt(Number(filters.clientId), 1)) && !filters.partnerId && !filters.sessionId).map(r => { const s = JSON.parse(String(r.snapshot)); return { id: r.id, quantity: r.quantity, unitCost: s.preview.calculation.cost, materials: s.preview.materials }; }).filter(r => !filters.materialId || r.materials.some((m) => m.materialId === Number(filters.materialId))).map(({ materials, ...row }) => row);
        const consignedResult = finance.list({ ...filters, origin: 'consigned' }).reduce((n, t) => n + Number(t.metadata.netSaleCents ?? 0) - t.amount_cents, 0);
        const clientLoss = db.prepare("SELECT 1 FROM sqlite_master WHERE name='client_destinations'").get() ? db.prepare("SELECT d.*,s.product_id,s.order_id FROM client_destinations d JOIN stock_items s ON s.id=d.item_id WHERE d.kind='discard'").all().filter(r => inPeriod(r.registered_at) && (!filters.productId || Number(r.product_id) === Number(filters.productId)) && (!filters.orderId || r.order_id === filters.orderId)).reduce((n, r) => n + Number(r.quantity), 0) : 0;
        return { summary: finance.summary(filters), loss, production, consignedResult, clientLoss, note: 'Custos de produção e perdas são analíticos, não novas saídas de caixa. Caixa não é lucro. Perdas manuais sem vínculo com produto/pedido/parceiro/sessão não são atribuídas por estimativa. Origem filtra lançamentos financeiros; análise física usa seus vínculos reais.' };
    }));
}
