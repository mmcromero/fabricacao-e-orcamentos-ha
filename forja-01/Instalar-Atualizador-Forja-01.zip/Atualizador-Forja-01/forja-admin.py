#!/usr/bin/env python3
"""One sudo process owns planning, interactive approval and deployment. No password handling."""
import argparse
import importlib.util
import json
import os
from pathlib import Path


def run(bridge, descriptor, archive, root, work, backup=None, evidence=None, confirm=input):
    plan = bridge.execute(descriptor, archive, work/'plan', root, 'plan', backup=backup, evidence=evidence)
    print('Destino:', plan['version'], '| Nivel:', plan['securityLevel'], flush=True)
    for check in plan['requiredChecks']: print(' -', check, flush=True)
    for warning in plan['plan'].get('warnings', []): print('Aviso:', warning, flush=True)
    if plan['status'] != 'planned':
        for blocker in plan['plan']['blockers']: print('Bloqueio:', blocker, flush=True)
        return plan
    legacy = plan['plan']['legacyCurrent']
    if legacy and confirm('Origem legada. Digite ACEITAR LEGADO para continuar: ') != 'ACEITAR LEGADO':
        return {'status':'cancelled'}
    if confirm('Digite ATUALIZAR para autorizar esta publicacao: ') != 'ATUALIZAR':
        return {'status':'cancelled'}
    return bridge.execute(descriptor, archive, work/'apply', root, 'apply', True, legacy, backup, evidence)


def main():
    os.umask(0o077)
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--work',type=Path,required=True);p.add_argument('--root',type=Path,required=True)
    p.add_argument('--backup',type=Path);p.add_argument('--recovery-evidence',type=Path)
    a=p.parse_args(); result={'status':'failed','error':'Sessao administrativa interrompida; consultar recibos no servidor.'}
    try:
        if os.geteuid()!=0: raise ValueError('Executar pelo sudo interativo, sem conceder acesso Docker permanente.')
        spec=importlib.util.spec_from_file_location('bridge',a.work/'forja-update.py')
        bridge=importlib.util.module_from_spec(spec)
        import sys
        sys.dont_write_bytecode=True
        spec.loader.exec_module(bridge)
        result=run(bridge,a.work/'publication.json',a.work/'package.tar.gz',a.root,a.work,a.backup,a.recovery_evidence)
    except (KeyboardInterrupt,EOFError): result={'status':'cancelled'}
    except Exception: pass  # Do not log raw exceptions, subprocess output or terminal input.
    finally:
        path=a.work/'admin-result.json'
        # Sanitized report is readable by the SSH user inside their private staging directory.
        with path.open('x',encoding='utf-8') as f: json.dump(result,f,ensure_ascii=False,indent=2)
        path.chmod(0o644)
    print('Resultado:',result['status'],flush=True)
    return 0 if result['status'] in ('healthy','cancelled','blocked') else 1


if __name__=='__main__': raise SystemExit(main())
