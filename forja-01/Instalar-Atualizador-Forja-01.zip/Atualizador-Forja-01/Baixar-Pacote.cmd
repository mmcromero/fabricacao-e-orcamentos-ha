@echo off
powershell.exe -NoLogo -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0Forja01.ps1" -BaixarPacote
set "forja_download_exit=%ERRORLEVEL%"
echo.
pause
exit /b %forja_download_exit%
