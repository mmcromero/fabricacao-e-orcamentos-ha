@echo off
powershell.exe -NoLogo -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0Forja01.ps1"
set "forja_update_exit=%ERRORLEVEL%"
echo.
pause
exit /b %forja_update_exit%
