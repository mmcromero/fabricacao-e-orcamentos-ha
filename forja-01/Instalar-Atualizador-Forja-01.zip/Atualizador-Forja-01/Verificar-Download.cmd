@echo off
powershell.exe -NoLogo -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0Forja01.ps1" -VerificarDownload
set "forja_check_exit=%ERRORLEVEL%"
echo.
pause
exit /b %forja_check_exit%
