# Artesão Digital — Debian 0.2.0-dev.17

Leia manuals/DEBIAN.md antes de preparar uma instalação nova. Execute `python3 manage.py verify`. Nenhum serviço é instalado/iniciado pela extração.
