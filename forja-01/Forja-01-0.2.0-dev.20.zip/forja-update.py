#!/usr/bin/env python3
"""Bridge for the Windows launcher. Reuses packaged operations.py; no SSH/network setup."""
import argparse
import hashlib
import importlib.util
import json
import re
import sys
import tarfile
from pathlib import Path

REPOSITORY = 'mmcromero/fabricacao_e_orcamentos'
HEX = re.compile(r'^[0-9a-f]{64}$')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError('Campo JSON duplicado: ' + key)
            result[key] = value
        return result
    return json.loads(path.read_text(encoding='utf-8-sig'), object_pairs_hook=unique)


def validate_descriptor(value):
    if value.get('metadataVersion') != 1 or value.get('repository') != REPOSITORY or value.get('distribution') != 'debian':
        raise ValueError('Origem/formato dos metadados de publicação inválidos')
    if not isinstance(value.get('version'), str) or not value['version'] or not re.fullmatch(r'[0-9a-f]{40}', value.get('sourceCommit', '')):
        raise ValueError('Versão/commit de destino ausente ou inválido')
    policy = value.get('securityPolicy')
    if not isinstance(policy, dict) or type(policy.get('level')) is not int or policy['level'] not in (1, 2) or policy.get('decision') != 'explicit-owner-approval':
        raise ValueError('Nível de publicação ausente, inválido ou sem decisão aprovada')
    for field in ('sha256', 'policySha256'):
        if not HEX.fullmatch(value.get('package', {}).get(field, '')):
            raise ValueError('Integridade do pacote/política ausente')
    if not HEX.fullmatch(value.get('runner', {}).get('sha256', '')):
        raise ValueError('Integridade do runner ausente')
    return value


def prepare(descriptor, archive, stage):
    """All target checks precede access to the active installation or Docker."""
    d = validate_descriptor(read(descriptor))
    if sha(archive) != d['package']['sha256']:
        raise ValueError('SHA256 do pacote diverge da publicação oficial')
    if stage.exists():
        raise ValueError('Preparação deve usar diretório novo')
    with tarfile.open(archive, 'r:gz') as tar:
        seen = set()
        for member in tar.getmembers():
            name = Path(member.name)
            if name.is_absolute() or '..' in name.parts or not name.parts or name.parts[0] != 'artesao-digital-debian' or name.as_posix() in seen or not (member.isfile() or member.isdir()):
                raise ValueError('Pacote inseguro: caminho, link ou entrada inválida')
            seen.add(name.as_posix())
        stage.mkdir(mode=0o700)
        tar.extractall(stage, filter='data')
    package = stage / 'artesao-digital-debian'
    policy_path = package / 'operation-policy.json'
    if sha(policy_path) != d['package']['policySha256'] or read(policy_path) != d['securityPolicy']:
        raise ValueError('Nível/política do pacote inconsistente com a publicação')
    # Artifact SHA is authenticated by the official HTTPS descriptor before importing code.
    spec = importlib.util.spec_from_file_location('release_operations', package / 'operations.py')
    ops = importlib.util.module_from_spec(spec)
    previous_bytecode = sys.dont_write_bytecode
    try:
        sys.dont_write_bytecode = True
        spec.loader.exec_module(ops)
    finally:
        sys.dont_write_bytecode = previous_bytecode
    m = ops.verify_package(package)
    if m['sourceCommit'] != d['sourceCommit'] or m['releaseVersion'] != d['version']:
        raise ValueError('Versão/commit do pacote inconsistente com a publicação')
    ops.load_policy(d['securityPolicy'])
    return d, package, ops


def requirements(level):
    """Display only. Enforcement remains exclusively in packaged operations.plan/apply."""
    common = ['Versão/commit e integridade', 'Compatibilidade sem migração',
              'Preservação de dados, volumes e configuração', 'Imagem anterior e caminho de retorno',
              'Inicialização, healthcheck e versão efetiva após atualização', 'Registro do resultado']
    if level == 1:
        return common + ['Backup recomendado; certificação/cópia externa/recuperação não bloqueiam atualização comum']
    if level == 2:
        return common + ['Política Nível 2 completa e aprovada', 'Backup recente, íntegro e compatível',
                         'Evidência de recuperação e cópia independente conforme política aprovada']
    raise ValueError('Nível de publicação inválido')


def execute(descriptor, archive, stage, root, action, approve=False, allow_legacy=False, backup=None, evidence=None):
    if action == 'apply' and not approve:
        raise ValueError('Atualização real exige autorização explícita')
    d, package, ops = prepare(descriptor, archive, stage)
    if sha(Path(__file__)) != d['runner']['sha256']:
        raise ValueError('Runner inconsistente com a publicação')
    ops.ROOT = root.resolve()
    policy = d['securityPolicy']
    # Preserve the existing rule: an approved operational phase 2 cannot be lowered
    # merely by selecting an old level-1 publication. This never selects a default.
    active_policy = ops.ROOT / 'operation-policy.json'
    if active_policy.exists():
        active = ops.load_policy(read(active_policy))
        if active['level'] == 2 and policy['level'] == 1:
            raise ValueError('Publicação Nível 1 inconsistente com fase operacional Nível 2; requer decisão explícita, sem redução automática')
    result = {'version': d['version'], 'sourceCommit': d['sourceCommit'], 'securityLevel': policy['level'],
              'requiredChecks': requirements(policy['level']), 'action': action}
    plan = ops.plan(package, backup, evidence, policy=policy)
    result['plan'] = plan
    if plan['blockers'] or action == 'plan':
        result['status'] = 'blocked' if plan['blockers'] else 'planned'
        return result
    # No rebuilding from the active installation. The existing plan has already passed.
    image = 'artesao-forja:' + d['sourceCommit']
    ops.docker('build', '--tag', image, '--file', str(package / 'app/Dockerfile'), str(package / 'app'))
    result['deployment'] = ops.apply(package, backup, evidence, image, True, allow_legacy, policy=policy)
    result['observed'] = ops.collect()
    result['status'] = 'healthy' if result['observed']['matches'] and result['observed']['container']['health'] == 'healthy' and result['observed']['declared']['sourceCommit'] == d['sourceCommit'] and result['observed']['declared']['releaseVersion'] == d['version'] else 'failed'
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('descriptor', 'archive', 'stage', 'root'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--action', choices=('plan', 'apply'), default='plan')
    p.add_argument('--approve-update', action='store_true')
    p.add_argument('--allow-legacy-current', action='store_true')
    p.add_argument('--backup', type=Path)
    p.add_argument('--recovery-evidence', type=Path)
    a = p.parse_args()
    try:
        result = execute(a.descriptor, a.archive, a.stage, a.root, a.action, a.approve_update,
                         a.allow_legacy_current, a.backup, a.recovery_evidence)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result['status'] in ('planned', 'healthy') else 2
    except ValueError as error:
        print(json.dumps({'status': 'failed', 'error': str(error)}, ensure_ascii=False))
    except Exception:
        # Never echo subprocess output, credentials, environment or raw Docker logs.
        print(json.dumps({'status': 'failed', 'error': 'Operação recusada; verificar acesso, artefatos e recibo privado .operations. Nenhum retorno destrutivo foi executado.'}, ensure_ascii=False))
    return 1


if __name__ == '__main__':
    raise SystemExit(main())
